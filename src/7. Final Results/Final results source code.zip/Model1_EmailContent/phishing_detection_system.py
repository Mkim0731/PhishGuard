#!/usr/bin/env python3
"""
Phishing Detection System using BERT
=====================================

This script implements a comprehensive phishing detection system using BERT/DistilBERT
for text classification. It processes 6 different email datasets and trains a model
optimized for Chrome Extension deployment.

Author: AI Assistant
Date: 2024
"""

import pandas as pd
import numpy as np
import re
import warnings
import sys
from typing import List, Tuple, Dict, Any
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    roc_auc_score, confusion_matrix, classification_report
)
from sklearn.utils.class_weight import compute_class_weight
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import (
    DistilBertTokenizer, DistilBertForSequenceClassification,
    TrainingArguments, Trainer, EarlyStoppingCallback
)
import logging
from pathlib import Path
import json
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Suppress warnings
warnings.filterwarnings('ignore')

# Set random seeds for reproducibility
np.random.seed(42)
torch.manual_seed(42)

class EmailDataset(Dataset):
    """Custom Dataset class for email data"""
    
    def __init__(self, texts: List[str], labels: List[int], tokenizer, max_length: int = 512):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }

class PhishingDetector:
    """Main class for phishing detection system"""
    
    def __init__(self, model_name: str = "distilbert-base-uncased", max_length: int = 512, require_cuda: bool = False):
        self.model_name = model_name
        self.max_length = max_length
        self.tokenizer = DistilBertTokenizer.from_pretrained(model_name)
        self.model = None
        self.trainer = None
        
        # Check CUDA availability
        if torch.cuda.is_available():
            self.device = torch.device('cuda')
            logger.info(f"Using device: {self.device}")
            logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
            logger.info(f"CUDA memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            
            # Optimize CUDA settings
            torch.backends.cudnn.benchmark = True
            torch.backends.cudnn.deterministic = False
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            
            if torch.cuda.is_available():
                torch.cuda.set_device(0)
                torch.cuda.empty_cache()
                props = torch.cuda.get_device_properties(0)
                logger.info(f"GPU Compute Capability: {props.major}.{props.minor}")
                import os
                os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
                os.environ['TORCH_USE_CUDA_DSA'] = '1'
        else:
            if require_cuda:
                logger.error("CUDA is not available! This system requires GPU acceleration for training.")
                logger.error("Please ensure you have:")
                logger.error("1. CUDA-compatible GPU (RTX 5060 Ti recommended)")
                logger.error("2. CUDA toolkit installed")
                logger.error("3. PyTorch with CUDA support installed")
                logger.error("Run: pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118")
                sys.exit(1)
            else:
                self.device = torch.device('cpu')
                logger.info("CUDA not available, using CPU (slower but functional)")
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize email text"""
        if pd.isna(text) or text == '':
            return ''
        
        # Convert to string and lowercase
        text = str(text).lower()
        
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', text)
        
        # Remove URLs (but keep the fact that URLs were present)
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        urls_found = len(re.findall(url_pattern, text))
        text = re.sub(url_pattern, '[URL]', text)
        
        # Remove email addresses
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        text = re.sub(email_pattern, '[EMAIL]', text)
        
        # Remove phone numbers
        phone_pattern = r'(\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}'
        text = re.sub(phone_pattern, '[PHONE]', text)
        
        # Remove excessive whitespace and normalize
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        # Add URL count as context if URLs were found
        if urls_found > 0:
            text = f"[{urls_found} URLs] {text}"
        
        return text
    
    def load_and_preprocess_data(self) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """Load and preprocess all datasets"""
        logger.info("Loading and preprocessing datasets...")
        
        datasets_info = {
            'CEAS_08.csv': {'label_col': 'label', 'text_cols': ['subject', 'body'], 'phishing_label': 1},
            'Enron.csv': {'label_col': 'label', 'text_cols': ['subject', 'body'], 'phishing_label': 0},
            'Ling.csv': {'label_col': 'label', 'text_cols': ['subject', 'body'], 'phishing_label': 0},
            'Nazario.csv': {'label_col': 'label', 'text_cols': ['subject', 'body'], 'phishing_label': 1},
            'Nigerian_Fraud.csv': {'label_col': 'label', 'text_cols': ['subject', 'body'], 'phishing_label': 1},
            'SpamAssasin.csv': {'label_col': 'label', 'text_cols': ['subject', 'body'], 'phishing_label': 0}
        }
        
        all_data = []
        dataset_stats = {}
        
        for filename, info in datasets_info.items():
            logger.info(f"Processing {filename}...")
            
            try:
                # Load dataset
                df = pd.read_csv(filename)
                
                # Store original stats
                dataset_stats[filename] = {
                    'original_rows': len(df),
                    'original_columns': list(df.columns),
                    'missing_data': df.isnull().sum().to_dict(),
                    'label_distribution': df[info['label_col']].value_counts().to_dict()
                }
                
                # Handle missing values
                df = df.dropna(subset=info['text_cols'] + [info['label_col']])
                
                # Combine text columns
                df['combined_text'] = df[info['text_cols']].fillna('').apply(
                    lambda x: ' '.join(x.astype(str)), axis=1
                )
                
                # Clean text
                df['cleaned_text'] = df['combined_text'].apply(self.clean_text)
                
                # Standardize labels (1 = phishing, 0 = legitimate)
                if info['phishing_label'] == 0:
                    df['binary_label'] = 1 - df[info['label_col']]  # Flip labels
                else:
                    df['binary_label'] = df[info['label_col']]
                
                # Filter out empty texts after cleaning
                df = df[df['cleaned_text'].str.len() > 10]
                
                # Select relevant columns
                processed_df = df[['cleaned_text', 'binary_label']].copy()
                processed_df['dataset'] = filename
                
                all_data.append(processed_df)
                
                logger.info(f"Processed {len(processed_df)} samples from {filename}")
                
            except Exception as e:
                logger.error(f"Error processing {filename}: {str(e)}")
                continue
        
        # Combine all datasets
        combined_df = pd.concat(all_data, ignore_index=True)
        
        # Remove duplicates
        initial_size = len(combined_df)
        combined_df = combined_df.drop_duplicates(subset=['cleaned_text'])
        logger.info(f"Removed {initial_size - len(combined_df)} duplicate samples")
        
        # Final statistics
        dataset_stats['combined'] = {
            'total_samples': len(combined_df),
            'phishing_samples': combined_df['binary_label'].sum(),
            'legitimate_samples': len(combined_df) - combined_df['binary_label'].sum(),
            'class_balance': combined_df['binary_label'].mean()
        }
        
        logger.info(f"Total samples after preprocessing: {len(combined_df)}")
        logger.info(f"Phishing samples: {dataset_stats['combined']['phishing_samples']}")
        logger.info(f"Legitimate samples: {dataset_stats['combined']['legitimate_samples']}")
        logger.info(f"Class balance: {dataset_stats['combined']['class_balance']:.3f}")
        
        return combined_df, dataset_stats
    
    def create_data_loaders(self, df: pd.DataFrame, test_size: float = 0.2, val_size: float = 0.1):
        """Create train/validation/test data loaders"""
        logger.info("Creating data loaders...")
        
        # Split data
        train_df, temp_df = train_test_split(
            df, test_size=test_size + val_size, 
            random_state=42, stratify=df['binary_label']
        )
        
        val_df, test_df = train_test_split(
            temp_df, test_size=test_size/(test_size + val_size),
            random_state=42, stratify=temp_df['binary_label']
        )
        
        logger.info(f"Train samples: {len(train_df)}")
        logger.info(f"Validation samples: {len(val_df)}")
        logger.info(f"Test samples: {len(test_df)}")
        
        # Create datasets
        train_dataset = EmailDataset(
            train_df['cleaned_text'].tolist(),
            train_df['binary_label'].tolist(),
            self.tokenizer,
            self.max_length
        )
        
        val_dataset = EmailDataset(
            val_df['cleaned_text'].tolist(),
            val_df['binary_label'].tolist(),
            self.tokenizer,
            self.max_length
        )
        
        test_dataset = EmailDataset(
            test_df['cleaned_text'].tolist(),
            test_df['binary_label'].tolist(),
            self.tokenizer,
            self.max_length
        )
        
        return train_dataset, val_dataset, test_dataset, test_df
    
    def train_model(self, train_dataset, val_dataset, test_dataset, test_df):
        """Train the BERT model"""
        logger.info("Initializing model...")
        
        # Initialize model
        self.model = DistilBertForSequenceClassification.from_pretrained(
            self.model_name,
            num_labels=2,
            problem_type="single_label_classification"
        )
        
        # Move model to device
        self.model.to(self.device)
        
        # Compute class weights for handling imbalance
        train_labels = [item['labels'].item() for item in train_dataset]
        class_weights = compute_class_weight(
            'balanced', 
            classes=np.unique(train_labels), 
            y=train_labels
        )
        class_weights = torch.tensor(class_weights, dtype=torch.float).to(self.device)
        
        # Training arguments optimized for RTX 4070 SUPER (12.9 GB VRAM)
        # Note: output_dir is temporary, final model will be saved to trained_models folder
        training_args = TrainingArguments(
            output_dir='./phishing_model_temp',
            num_train_epochs=3,
            per_device_train_batch_size=16,  # Reduced to 16 to prevent memory errors (was 32)
            per_device_eval_batch_size=32,  # Reduced to 32 to prevent memory errors (was 64)
            warmup_steps=500,
            weight_decay=0.01,
            learning_rate=2e-5,
            logging_dir='./logs',
            logging_steps=50,  # More frequent logging for progress tracking
            eval_strategy="steps",  # Changed from evaluation_strategy (newer transformers API)
            eval_steps=500,
            save_strategy="steps",
            save_steps=500,
            load_best_model_at_end=True,
            metric_for_best_model="eval_f1",
            greater_is_better=True,
            report_to=None,  # Disable wandb
            seed=42,
            fp16=True,  # Enabled for RTX 4070 SUPER - faster training with minimal accuracy loss
            dataloader_pin_memory=True,
            dataloader_num_workers=2,  # Reduced to 2 to prevent memory errors (was 4, originally 8)
            gradient_accumulation_steps=1,
            gradient_checkpointing=False,  # Disabled - RTX 4070 SUPER has enough VRAM (was True)
            dataloader_drop_last=False,
            remove_unused_columns=False,
            push_to_hub=False,
            # Accelerate-specific optimizations
            prediction_loss_only=False,
            # Progress tracking
            disable_tqdm=False,  # Enable progress bars
            # Additional optimizations
            optim="adamw_torch",  # Use PyTorch's optimized AdamW
            max_grad_norm=1.0,  # Gradient clipping for stability
        )
        
        # Define compute_metrics function
        def compute_metrics(eval_pred):
            predictions, labels = eval_pred
            predictions = np.argmax(predictions, axis=1)
            
            accuracy = accuracy_score(labels, predictions)
            precision = precision_score(labels, predictions, average='weighted', zero_division=0)
            recall = recall_score(labels, predictions, average='weighted', zero_division=0)
            f1 = f1_score(labels, predictions, average='weighted', zero_division=0)
            
            return {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'eval_f1': f1  # Add this for the metric_for_best_model
            }
        
        # Custom trainer with class weights
        class WeightedTrainer(Trainer):
            def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
                labels = inputs.get("labels")
                outputs = model(**inputs)
                logits = outputs.get("logits")
                
                loss_fct = nn.CrossEntropyLoss(weight=class_weights)
                loss = loss_fct(logits.view(-1, 2), labels.view(-1))
                
                return (loss, outputs) if return_outputs else loss
        
        # Initialize trainer
        self.trainer = WeightedTrainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            compute_metrics=compute_metrics,
            callbacks=[EarlyStoppingCallback(early_stopping_patience=2)]
        )
        
        # Train model with GPU optimization
        logger.info("Starting training...")
        logger.info("="*60)
        logger.info("MODEL 1 TRAINING PROGRESS")
        logger.info("="*60)
        
        # Clear GPU cache before training
        torch.cuda.empty_cache()
        
        # Monitor GPU memory usage
        if torch.cuda.is_available():
            logger.info(f"GPU memory before training: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
            logger.info(f"GPU memory cached: {torch.cuda.memory_reserved() / 1e9:.2f} GB")
        
        # Track training time
        import time
        start_time = time.time()
        logger.info(f"Training started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("Estimated time: ~15-20 minutes (optimized for RTX 4070 SUPER)")
        logger.info("Progress will be shown below...")
        logger.info("="*60)
        
        self.trainer.train()
        
        # Calculate and log training time
        end_time = time.time()
        training_time = end_time - start_time
        minutes = int(training_time // 60)
        seconds = int(training_time % 60)
        logger.info("="*60)
        logger.info(f"Training completed in {minutes} minutes {seconds} seconds")
        logger.info(f"Training finished at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("="*60)
        
        # Clear GPU cache after training
        torch.cuda.empty_cache()
        
        if torch.cuda.is_available():
            logger.info(f"GPU memory after training: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
        
        # Evaluate on test set
        logger.info("Evaluating on test set...")
        test_results = self.trainer.evaluate(test_dataset)
        
        # Get predictions
        predictions = self.trainer.predict(test_dataset)
        y_pred = np.argmax(predictions.predictions, axis=1)
        y_true = test_df['binary_label'].values
        
        # Calculate metrics
        metrics = self.calculate_metrics(y_true, y_pred, predictions.predictions)
        
        return metrics, test_results
    
    def calculate_metrics(self, y_true, y_pred, y_pred_proba):
        """Calculate comprehensive evaluation metrics"""
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred),
            'recall': recall_score(y_true, y_pred),
            'f1_score': f1_score(y_true, y_pred),
            'roc_auc': roc_auc_score(y_true, y_pred_proba[:, 1])
        }
        
        return metrics
    
    def create_visualizations(self, metrics, dataset_stats, test_df):
        """Create comprehensive visualizations"""
        logger.info("Creating visualizations...")
        
        # Set style
        plt.style.use('seaborn-v0_8')
        
        # Create figure with 3 subplots: Training curves (2) + Confusion matrix (1)
        fig = plt.figure(figsize=(15, 5))
        
        # Extract training history from trainer
        train_loss = []
        train_acc = []
        val_loss = []
        val_acc = []
        epochs = []
        
        if self.trainer and hasattr(self.trainer, 'state') and hasattr(self.trainer.state, 'log_history'):
            for log in self.trainer.state.log_history:
                if 'loss' in log and 'epoch' in log:
                    epochs.append(log['epoch'])
                    train_loss.append(log['loss'])
                if 'eval_loss' in log and 'epoch' in log:
                    val_loss.append(log['eval_loss'])
                if 'eval_accuracy' in log and 'epoch' in log:
                    val_acc.append(log['eval_accuracy'])
        
        # 1. Training Curves - Accuracy
        ax1 = plt.subplot(1, 3, 1)
        if epochs and val_acc:
            # Get unique epochs and corresponding accuracies
            unique_epochs = sorted(set(epochs))
            if len(unique_epochs) > 0:
                # Plot validation accuracy (we don't have train accuracy in log_history easily)
                plt.plot(unique_epochs[:len(val_acc)], val_acc, 'o-', label='Val Accuracy', linewidth=2, markersize=6)
        plt.title('Accuracy Over Epochs', fontsize=14, fontweight='bold')
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('Accuracy', fontsize=12)
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.ylim(0, 1)
        
        # 2. Training Curves - Loss
        ax2 = plt.subplot(1, 3, 2)
        if epochs and train_loss and val_loss:
            unique_epochs = sorted(set(epochs))
            if len(unique_epochs) > 0:
                plt.plot(unique_epochs[:len(train_loss)], train_loss, 'o-', label='Train Loss', linewidth=2, markersize=6)
                plt.plot(unique_epochs[:len(val_loss)], val_loss, 's-', label='Val Loss', linewidth=2, markersize=6)
        plt.title('Loss Over Epochs', fontsize=14, fontweight='bold')
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('Loss', fontsize=12)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # 3. Confusion Matrix
        ax3 = plt.subplot(1, 3, 3)
        y_pred = self.trainer.predict(EmailDataset(
            test_df['cleaned_text'].tolist(),
            test_df['binary_label'].tolist(),
            self.tokenizer,
            self.max_length
        )).predictions
        y_pred = np.argmax(y_pred, axis=1)
        
        cm = confusion_matrix(test_df['binary_label'], y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax3,
                   xticklabels=['Legitimate', 'Phishing'],
                   yticklabels=['Legitimate', 'Phishing'])
        ax3.set_title('Confusion Matrix', fontsize=14, fontweight='bold')
        ax3.set_xlabel('Predicted', fontsize=12)
        ax3.set_ylabel('Actual', fontsize=12)
        
        plt.tight_layout()
        
        # Save to trained_models folder
        script_dir = Path(__file__).parent
        project_root = script_dir.parent
        save_dir = project_root / 'trained_models' / 'Model1'
        save_dir.mkdir(parents=True, exist_ok=True)
        
        plt.savefig(save_dir / 'training_curves_and_confusion_matrix.png', dpi=300, bbox_inches='tight')
        logger.info(f"Visualizations saved to {save_dir / 'training_curves_and_confusion_matrix.png'}")
        plt.show()
        
        return fig
    
    def save_model(self, output_dir: str = './phishing_model'):
        """Save the trained model"""
        logger.info(f"Saving model to {output_dir}")
        if self.trainer is not None:
            self.trainer.save_model(output_dir)
        elif self.model is not None:
            self.model.save_pretrained(output_dir)
        else:
            raise ValueError("No model to save. Train or load a model first.")
        self.tokenizer.save_pretrained(output_dir)
        logger.info(f"Model saved successfully to {output_dir}")
    
    def load_model(self, model_path: str = './phishing_model'):
        """Load a trained model from disk"""
        logger.info(f"Loading model from {model_path}")
        if not Path(model_path).exists():
            raise FileNotFoundError(f"Model not found at {model_path}. Please train the model first.")
        
        # Load model
        self.model = DistilBertForSequenceClassification.from_pretrained(model_path)
        self.model.to(self.device)
        self.model.eval()  # Set to evaluation mode
        
        # Load tokenizer - try model_path first, fallback to base model if tokenizer files missing
        tokenizer_path = model_path
        vocab_file = Path(model_path) / 'vocab.txt'
        if not vocab_file.exists():
            logger.warning(f"Tokenizer files not found in {model_path}, using base model tokenizer: {self.model_name}")
            tokenizer_path = self.model_name
        self.tokenizer = DistilBertTokenizer.from_pretrained(tokenizer_path)
        
        logger.info(f"Model loaded successfully from {model_path}")
    
    def predict(self, email_text: str) -> Dict[str, Any]:
        """Predict if email is phishing
        
        Args:
            email_text: Combined email text (subject + body)
            
        Returns:
            Dictionary with prediction results:
            {
                'is_phishing': bool,
                'phishing_probability': float,
                'legitimate_probability': float,
                'confidence': float
            }
        """
        if self.model is None:
            raise ValueError("Model not loaded. Call load_model() first or train the model.")
        
        if not email_text or len(str(email_text).strip()) < 5:
            logger.warning("Empty or very short email text provided. Returning default prediction.")
            return {
                'is_phishing': False,
                'phishing_probability': 0.0,
                'legitimate_probability': 1.0,
                'confidence': 1.0
            }
        
        # Clean the text (same preprocessing as training)
        cleaned_text = self.clean_text(email_text)
        
        if not cleaned_text or len(cleaned_text.strip()) < 5:
            logger.warning("After cleaning, text is too short. Using original text.")
            cleaned_text = str(email_text).strip()[:1000]  # Use first 1000 chars
        
        # Tokenize
        try:
            encoding = self.tokenizer(
                cleaned_text,
                truncation=True,
                padding='max_length',
                max_length=self.max_length,
                return_tensors='pt'
            )
        except Exception as e:
            logger.error(f"Tokenization error: {e}")
            raise ValueError(f"Failed to tokenize email text: {str(e)}")
        
        # Move to device
        encoding = {k: v.to(self.device) for k, v in encoding.items()}
        
        # Predict
        try:
            with torch.no_grad():
                self.model.eval()  # Ensure model is in eval mode
                outputs = self.model(**encoding)
                logits = outputs.logits
                
                # Validate logits
                if logits is None or logits.shape[1] != 2:
                    logger.error(f"Invalid logits shape: {logits.shape if logits is not None else 'None'}")
                    raise ValueError("Model returned invalid logits")
                
                probabilities = torch.nn.functional.softmax(logits, dim=-1)
                
                # Validate probabilities sum to ~1.0
                prob_sum = probabilities[0].sum().item()
                if abs(prob_sum - 1.0) > 0.01:
                    logger.error(f"Probabilities don't sum to 1.0: {prob_sum}")
                    raise ValueError(f"Invalid probability distribution: sum={prob_sum}")
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            import traceback
            logger.error(traceback.format_exc())
            raise
        
        # Get prediction
        predicted_class = probabilities.argmax().item()
        phishing_prob = float(probabilities[0][1].item())
        legitimate_prob = float(probabilities[0][0].item())
        
        # Final validation
        if phishing_prob < 0 or phishing_prob > 1 or legitimate_prob < 0 or legitimate_prob > 1:
            logger.error(f"Invalid probabilities: phishing={phishing_prob}, legitimate={legitimate_prob}")
            raise ValueError(f"Invalid probability values: phishing={phishing_prob}, legitimate={legitimate_prob}")
        
        # Log prediction for debugging
        logger.info(f"Prediction: class={predicted_class}, phishing={phishing_prob:.4f}, legitimate={legitimate_prob:.4f}")
        
        return {
            'is_phishing': bool(predicted_class),
            'phishing_probability': phishing_prob,
            'legitimate_probability': legitimate_prob,
            'confidence': max(phishing_prob, legitimate_prob)
        }
    
    def generate_report(self, metrics, dataset_stats, test_results):
        """Generate comprehensive report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'model_info': {
                'model_name': self.model_name,
                'max_length': self.max_length,
                'device': str(self.device)
            },
            'dataset_statistics': dataset_stats,
            'performance_metrics': metrics,
            'test_results': test_results,
            'summary': {
                'total_samples': dataset_stats['combined']['total_samples'],
                'phishing_samples': dataset_stats['combined']['phishing_samples'],
                'legitimate_samples': dataset_stats['combined']['legitimate_samples'],
                'class_balance': dataset_stats['combined']['class_balance'],
                'accuracy': metrics['accuracy'],
                'f1_score': metrics['f1_score'],
                'roc_auc': metrics['roc_auc']
            }
        }
        
        # Save report
        with open('phishing_detection_report.json', 'w') as f:
            json.dump(report, f, indent=2)
        
        return report

def main():
    """Main execution function"""
    import os
    from pathlib import Path
    
    logger.info("Starting Phishing Detection System")
    
    # Determine model save path (relative to Final_Project root)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    model_save_path = project_root / 'trained_models' / 'Model1'
    model_save_path.mkdir(parents=True, exist_ok=True)
    
    # Initialize detector (REQUIRE CUDA for training - CPU would take days)
    if not torch.cuda.is_available():
        logger.error("="*60)
        logger.error("ERROR: CUDA GPU is REQUIRED for training!")
        logger.error("="*60)
        logger.error("Training on CPU would take DAYS to complete.")
        logger.error("Please ensure you have:")
        logger.error("1. CUDA-compatible GPU installed")
        logger.error("2. NVIDIA drivers installed")
        logger.error("3. CUDA toolkit installed (11.8 or 12.1)")
        logger.error("4. PyTorch with CUDA support")
        logger.error("")
        logger.error("Install PyTorch with CUDA:")
        logger.error("pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118")
        logger.error("="*60)
        sys.exit(1)
    
    detector = PhishingDetector(require_cuda=True)
    logger.info("✅ GPU detected - training will proceed")
    
    # Load and preprocess data
    df, dataset_stats = detector.load_and_preprocess_data()
    
    # Create data loaders
    train_dataset, val_dataset, test_dataset, test_df = detector.create_data_loaders(df)
    
    # Train model
    metrics, test_results = detector.train_model(train_dataset, val_dataset, test_dataset, test_df)
    
    # Create visualizations
    detector.create_visualizations(metrics, dataset_stats, test_df)
    
    # Save model to trained_models folder
    detector.save_model(str(model_save_path))
    
    # Generate report
    report = detector.generate_report(metrics, dataset_stats, test_results)
    
    # Print summary
    print("\n" + "="*60)
    print("PHISHING DETECTION SYSTEM - FINAL RESULTS")
    print("="*60)
    print(f"Total Samples Processed: {report['summary']['total_samples']:,}")
    print(f"Phishing Samples: {report['summary']['phishing_samples']:,}")
    print(f"Legitimate Samples: {report['summary']['legitimate_samples']:,}")
    print(f"Class Balance: {report['summary']['class_balance']:.3f}")
    print("\nModel Performance:")
    print(f"Accuracy: {report['summary']['accuracy']:.4f}")
    print(f"F1-Score: {report['summary']['f1_score']:.4f}")
    print(f"ROC-AUC: {report['summary']['roc_auc']:.4f}")
    print("="*60)
    
    logger.info("Phishing Detection System completed successfully!")

if __name__ == "__main__":
    main()
