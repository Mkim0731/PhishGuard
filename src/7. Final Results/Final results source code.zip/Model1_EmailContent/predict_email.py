#!/usr/bin/env python3
"""
Email Prediction Script
=======================

Use this script to make predictions on individual emails after training the model.
"""

import sys
import torch
from phishing_detection_system import PhishingDetector
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_model_and_predict(email_text: str, model_path: str = './phishing_model'):
    """Load trained model and make prediction"""
    
    # Initialize detector
    detector = PhishingDetector()
    
    # Load trained model
    logger.info(f"Loading model from {model_path}...")
    detector.model = detector.trainer.model if hasattr(detector, 'trainer') and detector.trainer else None
    
    if detector.model is None:
        # Load from saved model
        from transformers import DistilBertForSequenceClassification
        detector.model = DistilBertForSequenceClassification.from_pretrained(model_path)
        detector.model.to(detector.device)
    
    detector.model.eval()  # Set to evaluation mode
    
    # Clean the text (same preprocessing as training)
    cleaned_text = detector.clean_text(email_text)
    
    # Tokenize
    encoding = detector.tokenizer(
        cleaned_text,
        truncation=True,
        padding='max_length',
        max_length=detector.max_length,
        return_tensors='pt'
    )
    
    # Move to device
    encoding = {k: v.to(detector.device) for k, v in encoding.items()}
    
    # Predict
    with torch.no_grad():
        outputs = detector.model(**encoding)
        logits = outputs.logits
        probabilities = torch.nn.functional.softmax(logits, dim=-1)
    
    # Get prediction
    predicted_class = probabilities.argmax().item()
    phishing_prob = probabilities[0][1].item()
    legitimate_prob = probabilities[0][0].item()
    
    result = {
        'is_phishing': bool(predicted_class),
        'phishing_probability': phishing_prob,
        'legitimate_probability': legitimate_prob,
        'confidence': max(phishing_prob, legitimate_prob)
    }
    
    return result

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python predict_email.py '<email_text>'")
        print("\nExample:")
        print('python predict_email.py "Subject: Urgent Action Required Body: Your account has been compromised. Click here to verify: http://fake-bank.com/verify"')
        sys.exit(1)
    
    email_text = sys.argv[1]
    
    try:
        result = load_model_and_predict(email_text)
        
        print("\n" + "="*60)
        print("PHISHING DETECTION RESULT")
        print("="*60)
        print(f"Email Text: {email_text[:100]}...")
        print(f"\nPrediction: {'⚠️  PHISHING' if result['is_phishing'] else '✅ LEGITIMATE'}")
        print(f"Phishing Probability: {result['phishing_probability']:.2%}")
        print(f"Legitimate Probability: {result['legitimate_probability']:.2%}")
        print(f"Confidence: {result['confidence']:.2%}")
        print("="*60)
        
    except FileNotFoundError:
        print("❌ Error: Model not found!")
        print("Please train the model first by running:")
        print("python phishing_detection_system.py")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()

