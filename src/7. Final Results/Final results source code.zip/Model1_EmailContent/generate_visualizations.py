#!/usr/bin/env python3
"""
Generate Model 1 Visualizations
=================================
This script regenerates training curves and confusion matrix for Model 1
similar to Model 2's visualizations.
"""

import sys
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.metrics import confusion_matrix

# Add parent directory to path
script_dir = Path(__file__).parent
project_root = script_dir.parent
sys.path.insert(0, str(script_dir))

from phishing_detection_system import PhishingDetector

def main():
    """Generate visualizations for Model 1"""
    print("="*60)
    print("GENERATING MODEL 1 VISUALIZATIONS")
    print("="*60)
    
    # Load the trained model
    model_path = project_root / 'trained_models' / 'Model1'
    
    if not model_path.exists():
        print(f"ERROR: Model not found at {model_path}")
        print("Please train Model 1 first.")
        return
    
    print(f"Loading model from: {model_path}")
    detector = PhishingDetector()
    detector.load_model(str(model_path))
    
    # Load test data to generate confusion matrix
    print("Loading test data...")
    df, _ = detector.load_and_preprocess_data()
    _, _, test_dataset, test_df = detector.create_data_loaders(df)
    
    # Get predictions
    print("Generating predictions...")
    predictions = detector.trainer.predict(test_dataset)
    y_pred = np.argmax(predictions.predictions, axis=1)
    y_true = test_df['binary_label'].values
    
    # Calculate metrics
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred),
        'recall': recall_score(y_true, y_pred),
        'f1_score': f1_score(y_true, y_pred),
    }
    
    print(f"\nModel Performance:")
    print(f"  Accuracy: {metrics['accuracy']:.4f}")
    print(f"  Precision: {metrics['precision']:.4f}")
    print(f"  Recall: {metrics['recall']:.4f}")
    print(f"  F1-Score: {metrics['f1_score']:.4f}")
    
    # Create visualizations
    print("\nCreating visualizations...")
    detector.create_visualizations(metrics, {}, test_df)
    
    print("\n✅ Visualizations generated successfully!")
    print(f"Saved to: {model_path / 'training_curves_and_confusion_matrix.png'}")

if __name__ == "__main__":
    main()





