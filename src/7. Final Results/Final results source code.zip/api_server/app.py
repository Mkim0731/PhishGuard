#!/usr/bin/env python3
"""
PhishGuard API Server
=====================

Flask API server that loads both ML models and provides prediction endpoints.
Runs on localhost:5000 by default.
"""

import os
import sys
import gc
import psutil
from pathlib import Path
from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import threading

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Allow Chrome extension to make requests

# Global variables for models
model1 = None
model2 = None
model1_lock = threading.Lock()
model2_lock = threading.Lock()
model1_loading = False
model2_loading = False

def check_memory():
    """Check available system memory"""
    try:
        mem = psutil.virtual_memory()
        available_gb = mem.available / (1024**3)
        total_gb = mem.total / (1024**3)
        logger.info(f"Available memory: {available_gb:.2f} GB / {total_gb:.2f} GB")
        return available_gb
    except Exception:
        return None

def load_model1_lazy():
    """Lazy load Model 1 (only when needed)"""
    global model1, model1_loading
    
    with model1_lock:
        if model1 is not None:
            return model1
        
        if model1_loading:
            # Another thread is loading, wait
            while model1_loading:
                import time
                time.sleep(0.1)
            return model1
        
        model1_loading = True
        
        try:
            # Check memory before loading
            available_mem = check_memory()
            if available_mem and available_mem < 2.0:
                logger.warning(f"Low memory ({available_mem:.2f} GB). Model 1 may fail to load.")
            
            # Get paths relative to this file
            script_dir = Path(__file__).parent
            project_root = script_dir.parent
            models_dir = project_root / 'trained_models'
            
            # Prevent TensorFlow from loading when importing transformers
            # This helps avoid paging file errors
            import os
            os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress TensorFlow warnings
            os.environ['TF_DISABLE_MKL'] = '1'  # Disable MKL to reduce memory
            # Prevent transformers from trying to import TensorFlow
            os.environ['TRANSFORMERS_NO_TF'] = '1'  # Disable TensorFlow in transformers
            
            sys.path.insert(0, str(project_root / 'Model1_EmailContent'))
            
            # Try to import with error handling
            try:
                # Note: We tried blocking TensorFlow but it still loads via tf_keras
                # Since direct import test works, let's just import normally
                from phishing_detection_system import PhishingDetector
            except ImportError as e:
                # If transformers import fails, it might be due to TensorFlow
                if 'tensorflow' in str(e).lower() or 'paging file' in str(e).lower():
                    raise RuntimeError(
                        "Failed to import Model 1 dependencies. This is likely due to insufficient Windows paging file. "
                        "Please increase your virtual memory settings. See MEMORY_OPTIMIZATION.md for instructions."
                    ) from e
                raise
            except Exception as e:
                # Catch any other import errors
                logger.error(f"Import error details: {type(e).__name__}: {str(e)}")
                raise
            
            model1_path = models_dir / 'Model1'
            if not model1_path.exists():
                raise FileNotFoundError(f"Model 1 not found at {model1_path}. Please train the models first.")
            
            logger.info(f"Loading Model 1 from {model1_path}...")
            logger.info(f"Model 1 path exists: {model1_path.exists()}")
            logger.info(f"Model 1 path absolute: {Path(model1_path).resolve()}")
            
            # Force garbage collection before loading
            gc.collect()
            
            # Load with memory optimizations
            logger.info("Creating PhishingDetector instance...")
            model1 = PhishingDetector(require_cuda=False)
            logger.info("PhishingDetector created")
            
            model1_path_abs = str(Path(model1_path).resolve())
            logger.info(f"Calling load_model with path: {model1_path_abs}")
            model1.load_model(model1_path_abs)
            logger.info("load_model() completed")
            
            # Verify model loaded
            if model1.model is None:
                logger.error("CRITICAL: model1.model is None after load_model()!")
            else:
                logger.info(f"Model loaded: {type(model1.model)}")
            
            # Set to eval mode and clear cache
            if hasattr(model1, 'model') and model1.model is not None:
                model1.model.eval()
                logger.info("Model set to eval mode")
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    logger.info("CUDA cache cleared")
            
            # Verify predict method exists
            if not hasattr(model1, 'predict'):
                logger.error("CRITICAL: model1.predict() method not found!")
            else:
                logger.info("Model 1 has predict() method")
            
            logger.info("OK Model 1 loaded successfully")
            gc.collect()  # Clean up after loading
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"ERROR Failed to load Model 1: {str(e)}")
            logger.error(f"Full traceback:\n{error_trace}")
            model1 = None
            error_msg = str(e)
            if "paging file" in error_msg.lower() or "memory" in error_msg.lower():
                logger.error("MEMORY ERROR: Windows paging file may be too small.")
                logger.error("Solution: Increase virtual memory in Windows System Settings")
        finally:
            model1_loading = False
        
        return model1

def load_model2_lazy():
    """Lazy load Model 2 (only when needed)"""
    global model2, model2_loading
    
    with model2_lock:
        if model2 is not None:
            return model2
        
        if model2_loading:
            # Another thread is loading, wait
            while model2_loading:
                import time
                time.sleep(0.1)
            return model2
        
        model2_loading = True
        
        try:
            # Check memory before loading
            available_mem = check_memory()
            if available_mem and available_mem < 2.0:
                logger.warning(f"Low memory ({available_mem:.2f} GB). Model 2 may fail to load.")
            
            # Get paths relative to this file
            script_dir = Path(__file__).parent
            project_root = script_dir.parent
            models_dir = project_root / 'trained_models'
            
            sys.path.insert(0, str(project_root / 'Model2_URLDetection' / 'Source_Code'))
            from url_predictor import URLPhishingDetector
            
            model2_path = models_dir / 'Model2'
            if not model2_path.exists():
                raise FileNotFoundError(f"Model 2 not found at {model2_path}. Please train the models first.")
            
            logger.info(f"Loading Model 2 from {model2_path}...")
            
            # Force garbage collection before loading
            gc.collect()
            
            # Load model
            model2 = URLPhishingDetector()
            model2.load_model()
            
            logger.info("OK Model 2 loaded successfully")
            gc.collect()  # Clean up after loading
            
        except Exception as e:
            logger.error(f"ERROR Failed to load Model 2: {str(e)}")
            model2 = None
            error_msg = str(e)
            if "paging file" in error_msg.lower() or "memory" in error_msg.lower():
                logger.error("MEMORY ERROR: Windows paging file may be too small.")
                logger.error("Solution: Increase virtual memory in Windows System Settings")
        finally:
            model2_loading = False
        
        return model2

def load_models():
    """Load both ML models into memory (eager loading - for startup)"""
    global model1, model2
    
    logger.info("Checking system memory...")
    check_memory()
    
    logger.info("Models will be loaded on-demand (lazy loading) to save memory.")
    logger.info("First prediction request will trigger model loading.")
    
    # Try to preload Model 2 (smaller, more likely to succeed)
    try:
        logger.info("Attempting to preload Model 2...")
        load_model2_lazy()
    except Exception as e:
        logger.warning(f"Could not preload Model 2: {str(e)}")
    
    # Don't preload Model 1 - let it load on first request
    logger.info("Model 1 will load on first email prediction request.")

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    # Check memory status
    try:
        mem = psutil.virtual_memory()
        memory_info = {
            'available_gb': round(mem.available / (1024**3), 2),
            'total_gb': round(mem.total / (1024**3), 2),
            'percent_used': mem.percent
        }
    except Exception:
        memory_info = None
    
    return jsonify({
        'status': 'healthy',
        'model1_loaded': model1 is not None,
        'model2_loaded': model2 is not None,
        'memory': memory_info,
        'note': 'Models load on-demand (lazy loading) to save memory'
    })

@app.route('/predict-email', methods=['POST'])
def predict_email():
    """Predict if email content is phishing
    
    Request body:
    {
        "email_text": "Subject: ... Body: ..."
    }
    
    Returns:
    {
        "is_phishing": bool,
        "phishing_probability": float,
        "legitimate_probability": float,
        "confidence": float
    }
    """
    # Lazy load Model 1 if not already loaded
    current_model1 = load_model1_lazy()
    
    if current_model1 is None:
        # Try to get more details about why it failed
        # Check if there's a recent error in logs
        return jsonify({
            'error': 'Model 1 not loaded',
            'message': 'Failed to load email content model. This may be due to insufficient memory. Please check system memory and Windows paging file settings.',
            'note': 'Check server logs for detailed error information. The model may have failed to load due to memory or paging file issues.'
        }), 500
    
    try:
        data = request.get_json()
        if not data or 'email_text' not in data:
            return jsonify({'error': 'Missing email_text in request'}), 400
        
        email_text = data['email_text']
        
        # Make prediction
        result = current_model1.predict(email_text)
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error in predict_email: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/predict-url', methods=['POST'])
def predict_url():
    """Predict if URL is phishing
    
    Request body:
    {
        "url": "https://example.com"
    }
    
    Returns:
    {
        "is_phishing": bool,
        "phishing_probability": float,
        "legitimate_probability": float,
        "confidence": float
    }
    """
    # Lazy load Model 2 if not already loaded
    current_model2 = load_model2_lazy()
    
    if current_model2 is None:
        return jsonify({
            'error': 'Model 2 not loaded',
            'message': 'Failed to load URL detection model. This may be due to insufficient memory. Please check system memory and Windows paging file settings.'
        }), 500
    
    try:
        data = request.get_json()
        if not data or 'url' not in data:
            return jsonify({'error': 'Missing url in request'}), 400
        
        url = data['url']
        
        # Make prediction
        result = current_model2.predict_url(url)
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error in predict_url: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/predict-combined', methods=['POST'])
def predict_combined():
    """Predict using both models (email content + URLs)
    
    Request body:
    {
        "email_text": "Subject: ... Body: ...",
        "urls": ["https://url1.com", "https://url2.com"]
    }
    
    Returns:
    {
        "is_phishing": bool,
        "email_result": {...},
        "url_results": [...],
        "combined_confidence": float
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Empty request body'}), 400
        
        email_text = data.get('email_text', '')
        urls = data.get('urls', [])
        
        results = {
            'email_result': None,
            'url_results': [],
            'is_phishing': False,
            'combined_confidence': 0.0
        }
        
        # Predict email content (lazy load if needed)
        if email_text and len(email_text.strip()) > 0:
            logger.info(f"=== MODEL 1 PREDICTION START ===")
            logger.info(f"Email text length: {len(email_text)}")
            logger.info(f"Email text preview: {email_text[:200]}")
            
            current_model1 = load_model1_lazy()
            
            if current_model1 is None:
                logger.error("CRITICAL: Model 1 is None - failed to load!")
                results['email_result'] = {
                    'is_phishing': False,
                    'phishing_probability': 0.0,
                    'legitimate_probability': 1.0,
                    'confidence': 0.0,
                    'error': 'Model 1 failed to load'
                }
            else:
                logger.info(f"Model 1 loaded successfully: {type(current_model1)}")
                logger.info(f"Model 1 has predict method: {hasattr(current_model1, 'predict')}")
                if hasattr(current_model1, 'model'):
                    logger.info(f"Model 1 model object: {current_model1.model is not None}")
                
                try:
                    logger.info(f"Calling model1.predict() with text length: {len(email_text)}")
                    prediction_result = current_model1.predict(email_text)
                    logger.info(f"Prediction result type: {type(prediction_result)}")
                    logger.info(f"Prediction result: {prediction_result}")
                    
                    # Validate the result structure
                    if not isinstance(prediction_result, dict):
                        logger.error(f"ERROR: Prediction result is not a dict! Type: {type(prediction_result)}")
                        results['email_result'] = {
                            'is_phishing': False,
                            'phishing_probability': 0.0,
                            'legitimate_probability': 1.0,
                            'confidence': 0.0,
                            'error': 'Invalid prediction result format'
                        }
                    else:
                        # Ensure all required fields exist and are valid numbers
                        phishing_prob = float(prediction_result.get('phishing_probability', 0.0))
                        legit_prob = float(prediction_result.get('legitimate_probability', 0.0))
                        
                        # Validate probabilities are reasonable (should sum to ~1.0)
                        prob_sum = phishing_prob + legit_prob
                        if abs(prob_sum - 1.0) > 0.01:
                            logger.error(f"ERROR: Probabilities don't sum to 1.0! Sum: {prob_sum}, phishing: {phishing_prob}, legitimate: {legit_prob}")
                            # Normalize them
                            if prob_sum > 0:
                                phishing_prob = phishing_prob / prob_sum
                                legit_prob = legit_prob / prob_sum
                            else:
                                logger.error("Both probabilities are 0! Using default values.")
                                phishing_prob = 0.0
                                legit_prob = 1.0
                        
                        # Ensure probabilities are in valid range
                        phishing_prob = max(0.0, min(1.0, phishing_prob))
                        legit_prob = max(0.0, min(1.0, legit_prob))
                        
                        # REFINEMENT: If only 1 suspicious keyword found, cap at 25%
                        # This prevents single words from causing high false positives
                        suspicious_keywords = [
                            'urgent', 'immediately', 'verify', 'suspended', 'expired', 'limited time',
                            'click here', 'act now', 'confirm', 'update', 'security alert', 'unauthorized',
                            'verify account', 'verify identity', 'account locked', 'payment required',
                            'prize winner', 'congratulations', 'free money', 'claim now', 'click below',
                            'within 24 hours', 'within 48 hours', 'expires soon', 'deadline', 'last chance'
                        ]
                        
                        email_text_lower = email_text.lower()
                        found_keywords = [kw for kw in suspicious_keywords if kw in email_text_lower]
                        keyword_count = len(found_keywords)
                        
                        # If only 1 suspicious keyword, cap phishing probability at 25%
                        if keyword_count == 1:
                            logger.info(f"Only 1 suspicious keyword found ('{found_keywords[0]}'), capping phishing probability at 25%")
                            phishing_prob = min(phishing_prob, 0.25)
                            # Recalculate legitimate probability to sum to 1.0
                            legit_prob = 1.0 - phishing_prob
                        elif keyword_count == 0:
                            # No suspicious keywords - slightly reduce phishing probability
                            phishing_prob = phishing_prob * 0.9  # Reduce by 10%
                            legit_prob = 1.0 - phishing_prob
                        
                        # Update result with validated values
                        # Refined threshold: require > 65% for is_phishing (was 50%)
                        # This makes it less aggressive
                        is_phishing_flag = phishing_prob > 0.65
                        
                        results['email_result'] = {
                            'is_phishing': is_phishing_flag,
                            'phishing_probability': phishing_prob,
                            'legitimate_probability': legit_prob,
                            'confidence': max(phishing_prob, legit_prob)
                        }
                        
                        logger.info(f"After keyword adjustment: keyword_count={keyword_count}, phishing_prob={phishing_prob:.4f}, legit_prob={legit_prob:.4f}")
                        
                        logger.info(f"SUCCESS: Email prediction - phishing_prob: {phishing_prob:.4f}, legit_prob: {legit_prob:.4f}")
                        
                        # CRITICAL CHECK: If both probabilities are 0, something is very wrong
                        if phishing_prob == 0.0 and legit_prob == 0.0:
                            logger.error("CRITICAL ERROR: Both probabilities are 0%! This should never happen!")
                            logger.error("This indicates a serious problem with the model prediction.")
                            results['email_result']['error'] = 'Model returned invalid probabilities (both 0%)'
                        elif phishing_prob == 0.0 and legit_prob == 1.0:
                            logger.warning("WARNING: Model returned 0% phishing, 100% legitimate")
                            logger.warning("This might be correct, but verify the model is working properly")
                        
                except Exception as e:
                    import traceback
                    error_trace = traceback.format_exc()
                    logger.error(f"ERROR predicting email: {str(e)}")
                    logger.error(f"Full traceback:\n{error_trace}")
                    # Return a default result instead of None
                    results['email_result'] = {
                        'is_phishing': False,
                        'phishing_probability': 0.0,
                        'legitimate_probability': 1.0,
                        'confidence': 0.0,
                        'error': str(e)
                    }
        else:
            logger.warning(f"Empty or invalid email_text received (length: {len(email_text) if email_text else 0})")
            # Return default result for empty content
            results['email_result'] = {
                'is_phishing': False,
                'phishing_probability': 0.0,
                'legitimate_probability': 1.0,
                'confidence': 0.0
            }
        
        logger.info(f"=== MODEL 1 PREDICTION END ===")
        logger.info(f"Final email_result: {results['email_result']}")
        
        # Predict URLs (lazy load if needed)
        if urls:
            current_model2 = load_model2_lazy()
            if current_model2 is not None:
                for url in urls:
                    try:
                        url_result = current_model2.predict_url(url)
                        results['url_results'].append({
                            'url': url,
                            **url_result
                        })
                    except Exception as e:
                        logger.error(f"Error predicting URL {url}: {str(e)}")
        
        # Determine if phishing - REFINED THRESHOLDS (less aggressive)
        # Require higher confidence before marking as phishing
        
        # Email threshold: require > 65% phishing probability (was 50%)
        email_prob = results['email_result'].get('phishing_probability', 0) if results['email_result'] else 0
        email_phishing = email_prob > 0.65
        
        # URL threshold: require > 70% phishing probability AND at least 2 suspicious URLs (was 50% and any URL)
        url_probs = [r.get('phishing_probability', 0) for r in results['url_results']]
        high_risk_urls = [p for p in url_probs if p > 0.70]
        url_phishing = len(high_risk_urls) >= 2 or (len(high_risk_urls) >= 1 and max(url_probs) > 0.85)
        
        # Combined decision: require BOTH email AND URL to be suspicious, OR very high individual score
        # This prevents false positives from single indicators
        very_high_email = email_prob > 0.85
        very_high_url = max(url_probs) > 0.90 if url_probs else False
        
        # Mark as phishing only if:
        # 1. Both email AND URL are suspicious, OR
        # 2. Email is VERY high (>85%), OR
        # 3. URL is VERY high (>90%)
        results['is_phishing'] = (email_phishing and url_phishing) or very_high_email or very_high_url
        
        # Calculate combined confidence - use weighted average instead of max (more nuanced)
        confidences = []
        weights = []
        
        if results['email_result']:
            email_conf = email_prob
            confidences.append(email_conf)
            weights.append(0.6)  # Email gets 60% weight (more important)
        
        if url_probs:
            # Average of top 2 URLs (if multiple) or just the max
            if len(url_probs) >= 2:
                top_urls = sorted(url_probs, reverse=True)[:2]
                url_conf = sum(top_urls) / len(top_urls)
            else:
                url_conf = max(url_probs) if url_probs else 0
            confidences.append(url_conf)
            weights.append(0.4)  # URLs get 40% weight
        
        # Weighted average for more nuanced scoring
        if confidences and weights:
            total_weight = sum(weights)
            if total_weight > 0:
                weighted_sum = sum(c * w for c, w in zip(confidences, weights))
                results['combined_confidence'] = weighted_sum / total_weight
            else:
                results['combined_confidence'] = max(confidences) if confidences else 0.0
        else:
            results['combined_confidence'] = 0.0
        
        return jsonify(results)
    
    except Exception as e:
        logger.error(f"Error in predict_combined: {str(e)}")
        return jsonify({'error': str(e)}), 500

def main():
    """Main function to start the server"""
    print("="*60)
    print("PhishGuard API Server")
    print("="*60)
    print("\nLoading models...")
    
    try:
        load_models()
    except Exception as e:
        print(f"\nERROR: Failed to load models: {str(e)}")
        print("\nPlease ensure:")
        print("1. Models are trained and saved in trained_models/ folder")
        print("2. All dependencies are installed")
        print("3. Sufficient memory/paging file space available")
        print("\nServer will start anyway for debugging...")
        # Don't exit - allow server to start
    
    print("\n" + "="*60)
    print("Server starting on http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    print("="*60 + "\n")
    
    # Start Flask server
    app.run(
        host='localhost',
        port=5000,
        debug=False,  # Set to False for production
        threaded=True
    )

if __name__ == '__main__':
    main()


