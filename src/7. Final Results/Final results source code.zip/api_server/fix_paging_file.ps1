# PowerShell script to help users increase Windows paging file
# This script provides instructions and can check current settings

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Windows Paging File Configuration Helper" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "WARNING: This script needs administrator privileges to modify paging file settings." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "You can either:" -ForegroundColor White
    Write-Host "1. Run this script as Administrator (Right-click -> Run as Administrator)" -ForegroundColor Yellow
    Write-Host "2. Follow the manual instructions below" -ForegroundColor Yellow
    Write-Host ""
}

# Get current paging file settings
Write-Host "Current Paging File Settings:" -ForegroundColor Green
$pageFiles = Get-CimInstance -ClassName Win32_PageFileSetting
if ($pageFiles) {
    foreach ($pageFile in $pageFiles) {
        Write-Host "  Drive: $($pageFile.Name)" -ForegroundColor White
        Write-Host "  Initial Size: $($pageFile.InitialSize) MB" -ForegroundColor White
        Write-Host "  Maximum Size: $($pageFile.MaximumSize) MB" -ForegroundColor White
    }
} else {
    Write-Host "  No paging file configured (using system managed)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Recommended Settings:" -ForegroundColor Green
Write-Host "  Initial Size: 8192 MB (8 GB)" -ForegroundColor White
Write-Host "  Maximum Size: 16384 MB (16 GB)" -ForegroundColor White
Write-Host ""

# Get system memory
$mem = Get-CimInstance -ClassName Win32_ComputerSystem
$totalRAM = [math]::Round($mem.TotalPhysicalMemory / 1GB, 2)
Write-Host "System RAM: $totalRAM GB" -ForegroundColor Cyan
Write-Host ""

if ($isAdmin) {
    Write-Host "To automatically configure paging file:" -ForegroundColor Green
    Write-Host "1. This requires manual steps in System Properties" -ForegroundColor Yellow
    Write-Host "2. See instructions below" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Manual Configuration Steps:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Press Win + R, type 'sysdm.cpl', press Enter" -ForegroundColor White
Write-Host "2. Go to 'Advanced' tab" -ForegroundColor White
Write-Host "3. Click 'Settings' under Performance" -ForegroundColor White
Write-Host "4. Go to 'Advanced' tab" -ForegroundColor White
Write-Host "5. Click 'Change' under Virtual memory" -ForegroundColor White
Write-Host "6. Uncheck 'Automatically manage paging file size for all drives'" -ForegroundColor White
Write-Host "7. Select your system drive (usually C:)" -ForegroundColor White
Write-Host "8. Select 'Custom size'" -ForegroundColor White
Write-Host "9. Set Initial size: 8192" -ForegroundColor White
Write-Host "10. Set Maximum size: 16384" -ForegroundColor White
Write-Host "11. Click 'Set', then 'OK'" -ForegroundColor White
Write-Host "12. Restart your computer" -ForegroundColor White
Write-Host ""
Write-Host "After restart, the models should load successfully!" -ForegroundColor Green
Write-Host ""

# Try to open System Properties
$response = Read-Host "Would you like to open System Properties now? (Y/N)"
if ($response -eq 'Y' -or $response -eq 'y') {
    Start-Process "sysdm.cpl"
    Write-Host "System Properties opened. Follow the steps above." -ForegroundColor Green
}




