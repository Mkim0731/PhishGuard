# PowerShell script to move Windows paging file to N: drive
# This solves the issue when C: drive is low on space

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Move Paging File to N: Drive" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "WARNING: This script needs administrator privileges!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please:" -ForegroundColor Yellow
    Write-Host "1. Right-click PowerShell" -ForegroundColor White
    Write-Host "2. Select 'Run as Administrator'" -ForegroundColor White
    Write-Host "3. Run this script again" -ForegroundColor White
    Write-Host ""
    exit 1
}

# Check if N: drive exists
$nDrive = Get-PSDrive -Name N -ErrorAction SilentlyContinue
if (-not $nDrive) {
    Write-Host "ERROR: N: drive not found!" -ForegroundColor Red
    Write-Host "Please ensure N: drive is available." -ForegroundColor Yellow
    exit 1
}

# Get N: drive free space
$nDriveInfo = Get-CimInstance -ClassName Win32_LogicalDisk | Where-Object { $_.DeviceID -eq "N:" }
if ($nDriveInfo) {
    $freeSpaceGB = [math]::Round($nDriveInfo.FreeSpace / 1GB, 2)
    Write-Host "N: Drive Free Space: $freeSpaceGB GB" -ForegroundColor Green
    Write-Host ""
}

# Get current paging file settings
Write-Host "Current Paging File Settings:" -ForegroundColor Cyan
$pageFiles = Get-CimInstance -ClassName Win32_PageFileSetting
if ($pageFiles) {
    foreach ($pageFile in $pageFiles) {
        Write-Host "  Drive: $($pageFile.Name)" -ForegroundColor White
        Write-Host "  Initial Size: $($pageFile.InitialSize) MB" -ForegroundColor White
        Write-Host "  Maximum Size: $($pageFile.MaximumSize) MB" -ForegroundColor White
    }
} else {
    Write-Host "  System managed (on C: drive)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Recommended Action:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Since C: drive is low on space, we should:" -ForegroundColor Yellow
Write-Host "1. Remove paging file from C: drive" -ForegroundColor White
Write-Host "2. Create paging file on N: drive (with lots of space)" -ForegroundColor White
Write-Host ""
Write-Host "Recommended Settings for N: drive:" -ForegroundColor Green
Write-Host "  IMPORTANT: Use Custom size (NOT System managed)" -ForegroundColor Yellow
Write-Host "  - System managed may not create the file until needed" -ForegroundColor Gray
Write-Host "  - TensorFlow needs the file immediately when loading" -ForegroundColor Gray
Write-Host "  - Custom size ensures the file is created on restart" -ForegroundColor Gray
Write-Host ""
Write-Host "  Custom size settings:" -ForegroundColor White
Write-Host "    - Initial Size: 4096 MB (4 GB) - Creates file immediately" -ForegroundColor Green
Write-Host "    - Maximum Size: 16384 MB (16 GB) - Allows growth as needed" -ForegroundColor Green
Write-Host ""

# Manual instructions (since we can't modify paging file via PowerShell easily)
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Manual Steps to Move Paging File:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Press Win + R, type 'sysdm.cpl', press Enter" -ForegroundColor White
Write-Host "2. Go to 'Advanced' tab" -ForegroundColor White
Write-Host "3. Click 'Settings' under Performance" -ForegroundColor White
Write-Host "4. Go to 'Advanced' tab" -ForegroundColor White
Write-Host "5. Click 'Change' under Virtual memory" -ForegroundColor White
Write-Host "6. Uncheck 'Automatically manage paging file size'" -ForegroundColor White
Write-Host ""
Write-Host "7. SELECT C: DRIVE:" -ForegroundColor Yellow
Write-Host "   - Select 'No paging file'" -ForegroundColor White
Write-Host "   - Click 'Set'" -ForegroundColor White
Write-Host ""
Write-Host "8. SELECT N: DRIVE:" -ForegroundColor Yellow
Write-Host "   - Select 'Custom size' (REQUIRED - not System managed)" -ForegroundColor Green -BackgroundColor Black
Write-Host "   - Initial size: 4096 MB (4 GB)" -ForegroundColor Green -BackgroundColor Black
Write-Host "   - Maximum size: 16384 MB (16 GB)" -ForegroundColor Green -BackgroundColor Black
Write-Host "   - Click 'Set'" -ForegroundColor White
Write-Host ""
Write-Host "9. Click 'OK' on all windows" -ForegroundColor White
Write-Host "10. RESTART YOUR COMPUTER" -ForegroundColor Red -BackgroundColor Yellow
Write-Host ""

# Try to open System Properties
$response = Read-Host "Would you like to open System Properties now? (Y/N)"
if ($response -eq 'Y' -or $response -eq 'y') {
    Start-Process "sysdm.cpl"
    Write-Host ""
    Write-Host "System Properties opened. Follow the steps above." -ForegroundColor Green
    Write-Host ""
    Write-Host "IMPORTANT: After making changes, RESTART your computer!" -ForegroundColor Red -BackgroundColor Yellow
}


