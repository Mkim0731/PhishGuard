# Deep Analysis: "4. Paper Reproduction" Folder

## 📋 Executive Summary

This folder contains a **URL-based phishing detection model** using a **CNN (Convolutional Neural Network)** architecture with **TensorFlow/Keras**. This is fundamentally different from the email content model in "6. Initial Results" - it analyzes **URLs** rather than email text content. The model appears to be a reproduction of a research paper (likely "DePhides" based on the dataset URL).

---

## 📁 File Inventory

### Core Files

1. **`Source_Code/reproduction.py`** (5,931 bytes)
   - **Main training script** - Complete ML pipeline for URL classification
   - Uses TensorFlow/Keras (not PyTorch)
   - **Status**: ✅ Training pipeline complete, ❌ Missing inference methods

2. **`Source_Code/requirements.txt`** (348 bytes)
   - Python dependencies
   - TensorFlow 2.2.0, NumPy, scikit-learn, matplotlib, seaborn
   - **Status**: ✅ Complete

3. **`Source_Code/terminal output.txt`** (6,740 bytes)
   - Training logs showing model architecture and performance
   - Final test accuracy: **97.95%**
   - **Status**: ✅ Training completed successfully

4. **`Source_Code/Reproduction & Analysis_model.h5`** (1 byte - suspicious, may be placeholder)
   - Trained model file (Keras H5 format)
   - **Status**: ⚠️ File size suggests it may be empty or needs retraining

5. **`Source_Code/Reproduction & Analysis_tokenizer.pkl`** (2,294 bytes)
   - Character-level tokenizer (pickled)
   - **Status**: ✅ Available

6. **`Source_Code/confusion_matrix.png`** (21,986 bytes)
   - Visualization of model performance
   - **Status**: ✅ Available

7. **`Source_Code/Reproduction & Analysis_training_curves.png`** (51,477 bytes)
   - Training/validation accuracy and loss curves
   - **Status**: ✅ Available

8. **`Source_Code/Predicted Output with test.txt - predicted_output.csv`** (101 bytes)
   - Test predictions output
   - **Status**: ✅ Available

9. **`Source_Code/Predicted Output with test.txt - predicted_output.png`** (50,029 bytes)
   - Visualization of predictions
   - **Status**: ✅ Available

10. **`Dataset Descriptions.md`**
    - Documentation of 5 datasets considered
    - **Status**: ✅ Documentation available

---

## 🔍 Code Analysis

### Model Architecture

**Type**: CNN (Convolutional Neural Network) for URL classification

**Architecture Details:**
- **Input**: Character-level tokenized URLs (max length: 200 characters)
- **Embedding Layer**: 50-dimensional character embeddings
- **Convolutional Layers**: 3 Conv1D layers with kernel sizes [3, 4, 5]
  - Each with 128 filters
  - MaxPooling after each convolution
- **Pooling**: GlobalMaxPooling1D
- **Dense Layers**: 
  - 64-unit hidden layer with ReLU
  - 2-unit output layer (binary classification)
- **Dropout**: 0.5 rate for regularization
- **Total Parameters**: 178,976 (very lightweight!)

**Key Differences from "6. Initial Results" Model:**
| Feature | Paper Reproduction | Initial Results |
|---------|-------------------|-----------------|
| **Framework** | TensorFlow/Keras | PyTorch |
| **Architecture** | CNN | DistilBERT (Transformer) |
| **Input Type** | URLs (character-level) | Email content (word-level) |
| **Model Size** | ~179K parameters | ~66M parameters (DistilBERT) |
| **Max Length** | 200 characters | 512 tokens |
| **Tokenization** | Character-level | Word-level (BERT tokenizer) |
| **Accuracy** | 97.95% | ~92% (from README) |

---

## 🎯 What This Model Does

### Purpose
**Detects phishing URLs** by analyzing URL structure and character patterns.

### Input Format
- **Raw URL strings** (e.g., `"https://fake-bank.com/verify?token=abc123"`)
- Character-level tokenization (each character becomes a token)
- Padded/truncated to 200 characters

### Output Format
- Binary classification: `0` = legitimate, `1` = phishing
- Softmax probabilities for both classes

### Preprocessing
1. **Character-level tokenization**: Each character in URL is tokenized
2. **Padding/Truncation**: URLs padded or truncated to 200 characters
3. **No text cleaning**: Works directly on raw URL strings

---

## 📊 Model Performance

Based on terminal output:
- **Test Accuracy**: 97.95%
- **Precision**: 0.98 (both classes)
- **Recall**: 0.98 (both classes)
- **F1-Score**: 0.98 (both classes)
- **Training Time**: ~30 epochs, ~185s per epoch (~1.5 hours total)

**Test Set:**
- Benign URLs: 28,532 samples
- Phishing URLs: 22,977 samples
- Total: 51,509 samples

---

## 🔧 Code Structure Analysis

### ✅ **Implemented:**

1. **Data Loading** (`load_data()`)
   - Loads tab-separated files (label, URL)
   - Auto-downloads dataset from GitHub if missing
   - Converts labels: "legitimate" → 0, "phishing" → 1

2. **Preprocessing** (`preprocess()`)
   - Character-level tokenization
   - Sequence padding/truncation to MAX_LEN (200)

3. **Model Definition**
   - Complete CNN architecture
   - Compiled with Adam optimizer

4. **Training** (`model.fit()`)
   - 30 epochs
   - Batch size: 1000
   - Validation during training

5. **Evaluation**
   - Test set evaluation
   - Classification report
   - Confusion matrix

6. **Model Saving**
   - Saves model as H5 file
   - Saves tokenizer as pickle file

7. **Visualization**
   - Training curves (accuracy/loss)
   - Confusion matrix heatmap

### ❌ **Missing (Critical for Chrome Extension):**

1. **`load_model()`** - Load saved model for inference
2. **`predict()`** - Make predictions on new URLs
3. **`predict_url()`** - Standalone prediction function
4. **API integration** - No Flask/FastAPI server
5. **Batch prediction** - No support for multiple URLs

---

## 🎯 Data Flow Analysis

### Training Flow:
```
URL Strings → Character Tokenization → Padding → 
CNN Model → Training → Save Model + Tokenizer
```

### Expected Inference Flow (Not Implemented):
```
URL String → Character Tokenization → Padding → 
Load Model → Predict → Return probabilities
```

---

## 🚨 Critical Gaps for Chrome Extension

### 1. **Missing Prediction Methods**
- No `load_model()` method
- No `predict()` or `predict_url()` function
- Cannot use trained model for real-time detection

### 2. **Model File Issue**
- `Reproduction & Analysis_model.h5` is only 1 byte (likely empty/placeholder)
- May need to retrain model or locate actual model file

### 3. **No API Server**
- No Flask/FastAPI implementation
- Cannot serve predictions to Chrome extension

### 4. **Framework Mismatch**
- Uses TensorFlow 2.2.0 (older version)
- May conflict with other dependencies
- Consider upgrading to newer TensorFlow version

### 5. **No URL Extraction Logic**
- Model expects raw URLs
- Chrome extension needs to extract URLs from emails
- Need URL extraction from email body/links

---

## ✅ What's Working

1. **Complete Training Pipeline** - All training code is functional
2. **Character-Level Processing** - Good for URL analysis
3. **Lightweight Model** - Small model size (~179K params)
4. **High Accuracy** - 97.95% test accuracy
5. **Visualization** - Training curves and confusion matrix
6. **Auto-Download** - Automatically downloads dataset if missing
7. **Reproducibility** - Fixed random seeds for consistency

---

## 🔄 Comparison: Two-Model Approach

### Model 1: "6. Initial Results" (Email Content)
- **What it analyzes**: Email subject + body text
- **Architecture**: DistilBERT (Transformer)
- **Framework**: PyTorch
- **Input**: Combined email text (subject + body)
- **Use case**: Analyze email content for phishing indicators
- **Accuracy**: ~92%

### Model 2: "4. Paper Reproduction" (URLs)
- **What it analyzes**: URLs found in emails
- **Architecture**: CNN
- **Framework**: TensorFlow/Keras
- **Input**: Raw URL strings
- **Use case**: Analyze URLs/links for phishing indicators
- **Accuracy**: ~98%

### Combined Approach (Your Goal)
**Two-layer defense:**
1. **Content Analysis** (Model 1): Check email text for phishing language
2. **URL Analysis** (Model 2): Check all URLs in email for phishing patterns

**Decision Logic:**
- If either model flags as phishing → Show warning
- Combine probabilities for confidence score
- More robust than single model

---

## 🔧 Required Fixes/Additions

### Priority 1: Core Functionality
1. ✅ Verify/retrain model (H5 file seems empty)
2. ✅ Add `load_model()` function
3. ✅ Add `predict_url()` function
4. ✅ Test prediction functionality
5. ✅ Update TensorFlow version (if needed)

### Priority 2: API Server
1. ✅ Create Flask/FastAPI server
2. ✅ Endpoint: `POST /predict-url` - accepts URL, returns prediction
3. ✅ Load model once at startup
4. ✅ Handle CORS for Chrome extension

### Priority 3: Chrome Extension Integration
1. ✅ URL extraction from email body
2. ✅ Extract all links from email
3. ✅ Send URLs to API for analysis
4. ✅ Visual indicators for suspicious URLs
5. ✅ Combine with email content model predictions

### Priority 4: Model Optimization
1. ✅ Model quantization (if needed)
2. ✅ Batch prediction support
3. ✅ Caching for repeated URLs

---

## 📊 Current State Assessment

| Component | Status | Completeness |
|-----------|--------|---------------|
| Training Pipeline | ✅ Complete | 100% |
| Model Architecture | ✅ Complete | 100% |
| Data Preprocessing | ✅ Complete | 100% |
| Evaluation Metrics | ✅ Complete | 100% |
| Prediction Methods | ❌ Missing | 0% |
| Model File | ⚠️ Suspicious | ?% (needs verification) |
| API Server | ❌ Missing | 0% |
| Chrome Extension Integration | ❌ Missing | 0% |
| Documentation | ✅ Partial | 60% |

**Overall Project Completeness: ~35%**

---

## 🎯 Integration Strategy for Two-Model System

### Architecture Design:

```
Email Received
    ↓
┌─────────────────────────────────────┐
│  Chrome Extension                   │
│  - Extract email content            │
│  - Extract all URLs                 │
└─────────────────────────────────────┘
    ↓                    ↓
┌─────────────┐    ┌─────────────┐
│ Model 1 API │    │ Model 2 API │
│ (Email Text)│    │ (URLs)      │
│ DistilBERT  │    │ CNN         │
└─────────────┘    └─────────────┘
    ↓                    ↓
┌─────────────────────────────────────┐
│  Decision Engine                    │
│  - Combine predictions             │
│  - Calculate confidence             │
│  - Show warning if flagged          │
└─────────────────────────────────────┘
```

### Decision Logic:
```python
def is_phishing(email_text, urls):
    # Model 1: Email content analysis
    email_pred = model1.predict(email_text)
    email_phishing_prob = email_pred['phishing_probability']
    
    # Model 2: URL analysis
    url_predictions = [model2.predict_url(url) for url in urls]
    max_url_phishing_prob = max([p['phishing_probability'] for p in url_predictions])
    
    # Combined decision
    combined_prob = max(email_phishing_prob, max_url_phishing_prob)
    is_phishing = combined_prob > 0.5
    
    return {
        'is_phishing': is_phishing,
        'email_probability': email_phishing_prob,
        'url_probability': max_url_phishing_prob,
        'combined_confidence': combined_prob
    }
```

---

## 💡 Key Insights

1. **Different Input Types**: Model 1 analyzes text, Model 2 analyzes URLs - perfect complement
2. **Different Frameworks**: PyTorch vs TensorFlow - need separate API servers or unified interface
3. **High Accuracy**: Model 2 achieves 97.95% accuracy on URLs
4. **Lightweight**: Model 2 is much smaller (~179K vs ~66M parameters)
5. **Character-Level**: Model 2 uses character-level tokenization (good for URLs with special chars)
6. **Model File Issue**: H5 file appears empty - may need retraining
7. **Auto-Download**: Dataset automatically downloads from GitHub (convenient)

---

## 🔐 Security Considerations

1. **URL Validation**: Validate URLs before sending to model
2. **Rate Limiting**: Prevent API abuse
3. **Input Sanitization**: Sanitize URLs before processing
4. **Privacy**: URLs sent to API (consider local processing option)

---

## 📈 Performance Expectations

Based on terminal output:
- **Accuracy**: 97.95%
- **Inference Speed**: Very fast (small model, ~179K params)
- **Model Size**: ~1-2 MB (H5 format)
- **Training Time**: ~1.5 hours (30 epochs)

---

## ✅ Conclusion

This folder contains a **well-trained URL phishing detection model** with excellent accuracy (97.95%). However, like the "6. Initial Results" folder, it's **missing inference methods** and **API integration**.

**Key Strengths:**
- High accuracy (97.95%)
- Lightweight model
- Character-level processing (good for URLs)
- Complete training pipeline

**Key Gaps:**
- Missing prediction methods
- Model file may be empty (needs verification)
- No API server
- No Chrome extension integration

**The two-model approach is excellent:**
- Model 1 (Email Content) + Model 2 (URLs) = Comprehensive phishing detection
- Different input types complement each other
- Higher confidence when both models agree

**Estimated effort to complete**: 6-8 hours of development work.

---

## 🔄 Next Steps

1. **Verify model file** - Check if H5 file is valid or needs retraining
2. **Add prediction methods** - Implement `load_model()` and `predict_url()`
3. **Create API server** - Flask/FastAPI for URL predictions
4. **Integrate with Chrome extension** - URL extraction and analysis
5. **Combine with Model 1** - Unified decision engine

