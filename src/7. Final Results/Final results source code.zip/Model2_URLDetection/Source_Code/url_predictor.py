#!/usr/bin/env python3
"""
URL Phishing Detection - Prediction Module
===========================================

This module provides functions to load the trained CNN model and make predictions on URLs.
"""

import os
import numpy as np
import tensorflow as tf
import pickle
from pathlib import Path
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Configuration (must match training configuration)
MAX_LEN = 200

class URLPhishingDetector:
    """URL Phishing Detection using CNN"""
    
    def __init__(self, model_path=None, tokenizer_path=None):
        """Initialize the detector
        
        Args:
            model_path: Path to saved model.h5 file
            tokenizer_path: Path to saved tokenizer.pkl file
        """
        self.model = None
        self.tokenizer = None
        self.model_path = model_path
        self.tokenizer_path = tokenizer_path
        
        # Auto-detect paths if not provided
        if model_path is None or tokenizer_path is None:
            script_dir = Path(__file__).parent
            project_root = script_dir.parent.parent
            default_model_path = project_root / 'trained_models' / 'Model2' / 'model.h5'
            default_tokenizer_path = project_root / 'trained_models' / 'Model2' / 'tokenizer.pkl'
            
            if model_path is None:
                self.model_path = str(default_model_path)
            if tokenizer_path is None:
                self.tokenizer_path = str(default_tokenizer_path)
    
    def load_model(self, model_path=None, tokenizer_path=None):
        """Load the trained model and tokenizer
        
        Args:
            model_path: Path to model.h5 (optional, uses default if None)
            tokenizer_path: Path to tokenizer.pkl (optional, uses default if None)
        """
        if model_path:
            self.model_path = model_path
        if tokenizer_path:
            self.tokenizer_path = tokenizer_path
        
        # Check if files exist
        if not Path(self.model_path).exists():
            raise FileNotFoundError(
                f"Model not found at {self.model_path}. "
                "Please train the model first by running reproduction.py"
            )
        if not Path(self.tokenizer_path).exists():
            raise FileNotFoundError(
                f"Tokenizer not found at {self.tokenizer_path}. "
                "Please train the model first by running reproduction.py"
            )
        
        # Load model
        print(f"Loading model from {self.model_path}...")
        self.model = load_model(self.model_path)
        
        # Load tokenizer
        print(f"Loading tokenizer from {self.tokenizer_path}...")
        with open(self.tokenizer_path, 'rb') as f:
            self.tokenizer = pickle.load(f)
        
        print("Model and tokenizer loaded successfully!")
    
    def preprocess_url(self, url):
        """Preprocess URL for prediction (same as training)
        
        Args:
            url: Raw URL string
            
        Returns:
            Preprocessed URL sequence
        """
        if self.tokenizer is None:
            raise ValueError("Tokenizer not loaded. Call load_model() first.")
        
        # Convert URL to sequence
        seq = self.tokenizer.texts_to_sequences([url])
        # Pad/truncate to MAX_LEN
        padded = pad_sequences(seq, maxlen=MAX_LEN, padding='post', truncating='post')
        return padded
    
    def predict_url(self, url):
        """Predict if URL is phishing
        
        Args:
            url: Raw URL string to analyze
            
        Returns:
            Dictionary with prediction results:
            {
                'is_phishing': bool,
                'phishing_probability': float,
                'legitimate_probability': float,
                'confidence': float
            }
        """
        if self.model is None:
            raise ValueError("Model not loaded. Call load_model() first.")
        
        # Preprocess URL
        preprocessed = self.preprocess_url(url)
        
        # Make prediction
        predictions = self.model.predict(preprocessed, verbose=0)
        
        # Get probabilities
        legitimate_prob = float(predictions[0][0])
        phishing_prob = float(predictions[0][1])
        
        # Determine class - Refined threshold: require > 70% for phishing (was 50%)
        # This makes it less aggressive and reduces false positives
        is_phishing = phishing_prob > 0.70
        
        return {
            'is_phishing': is_phishing,
            'phishing_probability': phishing_prob,
            'legitimate_probability': legitimate_prob,
            'confidence': max(phishing_prob, legitimate_prob)
        }
    
    def predict_batch(self, urls):
        """Predict on multiple URLs
        
        Args:
            urls: List of URL strings
            
        Returns:
            List of prediction dictionaries
        """
        if self.model is None:
            raise ValueError("Model not loaded. Call load_model() first.")
        
        # Preprocess all URLs
        sequences = []
        for url in urls:
            seq = self.tokenizer.texts_to_sequences([url])
            sequences.extend(seq)
        
        # Pad sequences
        padded = pad_sequences(sequences, maxlen=MAX_LEN, padding='post', truncating='post')
        
        # Make predictions
        predictions = self.model.predict(padded, verbose=0)
        
        # Format results
        results = []
        for pred in predictions:
            legitimate_prob = float(pred[0])
            phishing_prob = float(pred[1])
            is_phishing = phishing_prob > 0.5
            
            results.append({
                'is_phishing': is_phishing,
                'phishing_probability': phishing_prob,
                'legitimate_probability': legitimate_prob,
                'confidence': max(phishing_prob, legitimate_prob)
            })
        
        return results


def main():
    """Example usage"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python url_predictor.py <url>")
        print("\nExample:")
        print('python url_predictor.py "https://fake-bank.com/verify?token=abc123"')
        sys.exit(1)
    
    url = sys.argv[1]
    
    try:
        # Initialize detector
        detector = URLPhishingDetector()
        
        # Load model
        detector.load_model()
        
        # Make prediction
        result = detector.predict_url(url)
        
        # Print results
        print("\n" + "="*60)
        print("URL PHISHING DETECTION RESULT")
        print("="*60)
        print(f"URL: {url}")
        print(f"\nPrediction: {'⚠️  PHISHING' if result['is_phishing'] else '✅ LEGITIMATE'}")
        print(f"Phishing Probability: {result['phishing_probability']:.2%}")
        print(f"Legitimate Probability: {result['legitimate_probability']:.2%}")
        print(f"Confidence: {result['confidence']:.2%}")
        print("="*60)
        
    except FileNotFoundError as e:
        print(f"❌ Error: {str(e)}")
        print("\nPlease train the model first by running:")
        print("python reproduction.py")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()






