// PhishGuard Popup Script

const API_URL = 'http://localhost:5000';

// DOM Elements
const emailInput = document.getElementById('emailInput');
const detectBtn = document.getElementById('detectBtn');
const loadFromPageBtn = document.getElementById('loadFromPageBtn');
const clearBtn = document.getElementById('clearBtn');
const resultsSection = document.getElementById('resultsSection');
const loadingState = document.getElementById('loadingState');
const errorState = document.getElementById('errorState');
const statusIndicator = document.getElementById('statusIndicator');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const apiStatus = document.getElementById('apiStatus');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAPIStatus();
    setupEventListeners();
    loadSavedEmail();
});

// Setup event listeners
function setupEventListeners() {
    detectBtn.addEventListener('click', handleDetect);
    loadFromPageBtn.addEventListener('click', loadEmailFromPage);
    clearBtn.addEventListener('click', clearEmail);
    
    // Dismiss error button
    const dismissErrorBtn = document.getElementById('dismissErrorBtn');
    if (dismissErrorBtn) {
        dismissErrorBtn.addEventListener('click', () => {
            document.getElementById('errorState').classList.add('hidden');
        });
    }
    
    // Show details button
    const showDetailsBtn = document.getElementById('showDetailsBtn');
    if (showDetailsBtn) {
        showDetailsBtn.addEventListener('click', () => {
            const detailsContent = document.getElementById('detailsContent');
            const detailsArrow = document.getElementById('detailsArrow');
            const isHidden = detailsContent.classList.contains('hidden');
            
            if (isHidden) {
                detailsContent.classList.remove('hidden');
                detailsArrow.style.transform = 'rotate(180deg)';
                showDetailsBtn.querySelector('span').textContent = 'Hide Details';
            } else {
                detailsContent.classList.add('hidden');
                detailsArrow.style.transform = 'rotate(0deg)';
                showDetailsBtn.querySelector('span').textContent = 'Show More Details';
            }
        });
    }
    
    // Show parsed email button
    const showParsedEmailBtn = document.getElementById('showParsedEmailBtn');
    if (showParsedEmailBtn) {
        showParsedEmailBtn.addEventListener('click', () => {
            const parsedContent = document.getElementById('parsedEmailContent');
            const parsedArrow = showParsedEmailBtn.querySelector('svg');
            const isHidden = parsedContent.classList.contains('hidden');
            
            if (isHidden) {
                parsedContent.classList.remove('hidden');
                parsedArrow.style.transform = 'rotate(180deg)';
                showParsedEmailBtn.querySelector('span').textContent = 'Hide Parsed Content';
            } else {
                parsedContent.classList.add('hidden');
                parsedArrow.style.transform = 'rotate(0deg)';
                showParsedEmailBtn.querySelector('span').textContent = 'Show Parsed Content';
            }
        });
    }
    
    // Auto-save email content
    emailInput.addEventListener('input', () => {
        chrome.storage.local.set({ emailContent: emailInput.value });
    });
}

// Check API server status
async function checkAPIStatus() {
    try {
        const response = await fetch(`${API_URL}/health`);
        const data = await response.json();
        
        if (data.status === 'healthy') {
            statusDot.classList.add('connected');
            statusText.textContent = 'Connected';
            apiStatus.textContent = 'API: Online';
            apiStatus.style.color = '#10b981';
        } else {
            throw new Error('API not healthy');
        }
    } catch (error) {
        statusDot.classList.add('error');
        statusText.textContent = 'Disconnected';
        apiStatus.textContent = 'API: Offline';
        apiStatus.style.color = '#ef4444';
        console.error('API check failed:', error);
    }
}

// Load email from current page
async function loadEmailFromPage() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        // Try to inject content script if not already injected
        try {
            chrome.tabs.sendMessage(tab.id, { action: 'extractEmail' }, (response) => {
                if (chrome.runtime.lastError) {
                    // Content script might not be loaded, try to inject it
                    console.log('Content script not loaded, injecting...');
                    chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['content.js']
                    }, () => {
                        // Wait a bit then try again
                        setTimeout(() => {
                            chrome.tabs.sendMessage(tab.id, { action: 'extractEmail' }, (response) => {
                                if (chrome.runtime.lastError) {
                                    // Fallback: get page HTML directly
                                    getPageContentDirectly(tab.id);
                                } else if (response && response.emailContent) {
                                    emailInput.value = response.emailContent;
                                    chrome.storage.local.set({ emailContent: response.emailContent });
                                } else {
                                    getPageContentDirectly(tab.id);
                                }
                            });
                        }, 500);
                    });
                } else if (response && response.emailContent) {
                    emailInput.value = response.emailContent;
                    chrome.storage.local.set({ emailContent: response.emailContent });
                } else {
                    getPageContentDirectly(tab.id);
                }
            });
        } catch (e) {
            // If scripting API fails, try direct method
            getPageContentDirectly(tab.id);
        }
    } catch (error) {
        showError('Failed to load email from page: ' + error.message);
    }
}

// Fallback: Get page content directly
function getPageContentDirectly(tabId) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => {
            // Get entire page HTML
            const html = document.documentElement.outerHTML;
            const url = window.location.href;
            const headers = `From: Page Content\nURL: ${url}\nDate: ${new Date().toISOString()}\n\n`;
            return headers + html;
        }
    }, (results) => {
        if (results && results[0] && results[0].result) {
            emailInput.value = results[0].result;
            chrome.storage.local.set({ emailContent: results[0].result });
        } else {
            showError('Could not extract page content. Please paste the email manually.');
        }
    });
}

// Clear email input
function clearEmail() {
    emailInput.value = '';
    chrome.storage.local.remove('emailContent');
    resultsSection.classList.add('hidden');
}

// Load saved email
function loadSavedEmail() {
    chrome.storage.local.get(['emailContent'], (result) => {
        if (result.emailContent) {
            emailInput.value = result.emailContent;
        }
    });
}

// Handle detection
async function handleDetect() {
    const emailContent = emailInput.value.trim();
    
    if (!emailContent) {
        showError('Please enter or paste email content first.');
        return;
    }
    
    // Show loading state
    detectBtn.disabled = true;
    if (resultsSection) resultsSection.classList.add('hidden');
    if (errorState) errorState.classList.add('hidden');
    if (loadingState) loadingState.classList.remove('hidden');
    
    console.log('=== STARTING DETECTION ===');
    console.log('Loading state shown');
    
    try {
        // Extract URLs from email (still needed for Model 2)
        const urls = extractURLs(emailContent);
        
        // NEW APPROACH: Send entire raw content to Model 1 (no parsing)
        // Model 1 can handle HTML, headers, and all content
        const finalEmailText = emailContent.trim();
        
        // Try to extract subject for display purposes only (not for analysis)
        const { subject } = parseEmail(emailContent);
        
        // Store content for display (CRITICAL - must be set before API call)
        window.lastParsedEmail = finalEmailText;
        window.lastSubject = subject || '';
        
        console.log('=== EMAIL ANALYSIS DEBUG ===');
        console.log('Raw content length:', finalEmailText.length);
        console.log('Content preview:', finalEmailText.substring(0, 300));
        console.log('URLs found:', urls.length);
        console.log('window.lastParsedEmail set to:', finalEmailText.substring(0, 100));
        console.log('Sending entire raw content to Model 1...');
        
        // Validate we have content before sending
        if (!finalEmailText || finalEmailText.length < 10) {
            throw new Error('No content to analyze. Please paste or load email content first.');
        }
        
        // Call API with the entire raw content
        console.log('=== SENDING TO API ===');
        console.log('Content length:', finalEmailText.length);
        console.log('First 500 chars:', finalEmailText.substring(0, 500));
        console.log('URLs:', urls);
        
        console.log('Calling API...');
        let result;
        try {
            result = await detectPhishing(finalEmailText, urls);
            console.log('=== API RESPONSE RECEIVED ===');
            console.log('Full result:', JSON.stringify(result, null, 2));
            console.log('email_result:', result.email_result);
            console.log('email_result type:', typeof result.email_result);
            console.log('email_result is null?', result.email_result === null);
            console.log('email_result is undefined?', result.email_result === undefined);
            
            if (result.email_result) {
                console.log('email_result.phishing_probability:', result.email_result.phishing_probability);
                console.log('email_result.legitimate_probability:', result.email_result.legitimate_probability);
                console.log('email_result.is_phishing:', result.email_result.is_phishing);
            } else {
                console.error('CRITICAL: email_result is null/undefined!');
                console.error('This means Model 1 did not return a result!');
            }
        } catch (apiError) {
            console.error('API call failed:', apiError);
            console.error('Error details:', apiError.message);
            console.error('Stack:', apiError.stack);
            throw apiError; // Re-throw to be caught by outer catch
        }
        
        // Hide loading state BEFORE displaying results
        console.log('Hiding loading state...');
        if (loadingState) {
            loadingState.classList.add('hidden');
            loadingState.style.setProperty('display', 'none', 'important');
        }
        
        // Display results - pass the raw content as parsedEmailText parameter
        console.log('Calling displayResults...');
        try {
            displayResults(result, urls, emailContent, subject || '', finalEmailText);
            console.log('displayResults completed successfully');
            
            // Ensure loading is hidden after display
            if (loadingState) {
                loadingState.classList.add('hidden');
                loadingState.style.setProperty('display', 'none', 'important');
            }
        } catch (displayError) {
            console.error('ERROR in displayResults:', displayError);
            console.error('Stack trace:', displayError.stack);
            // Still try to show something
            if (loadingState) {
                loadingState.classList.add('hidden');
                loadingState.style.setProperty('display', 'none', 'important');
            }
            if (resultsSection) {
                resultsSection.classList.remove('hidden');
                resultsSection.style.setProperty('display', 'block', 'important');
            }
            showError('Failed to display results: ' + displayError.message);
            throw displayError; // Re-throw so outer catch can handle it
        }
        
    } catch (error) {
        console.error('=== DETECTION ERROR ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error message:', error.message);
        console.error('Stack trace:', error.stack);
        
        // Hide loading, show error
        if (loadingState) loadingState.classList.add('hidden');
        if (errorState) {
            errorState.classList.remove('hidden');
            errorState.style.setProperty('display', 'block', 'important');
        }
        
        const errorMessageEl = document.getElementById('errorMessage');
        if (errorMessageEl) {
            errorMessageEl.textContent = 'Failed to analyze email: ' + error.message;
        }
        
        // Also try to show results section with error info
        if (resultsSection) {
            resultsSection.classList.remove('hidden');
            resultsSection.style.setProperty('display', 'block', 'important');
        }
        
        showError('Failed to analyze email: ' + error.message);
    } finally {
        detectBtn.disabled = false;
        if (loadingState) loadingState.classList.add('hidden');
        console.log('Detection process completed (success or error)');
    }
}

// Extract URLs from email content
function extractURLs(emailContent) {
    const urlRegex = /https?:\/\/[^\s<>"{}|\\^`\[\]]+/gi;
    const urls = emailContent.match(urlRegex) || [];
    // Remove duplicates
    return [...new Set(urls)];
}

// Decode quoted-printable encoding
function decodeQuotedPrintable(text) {
    return text
        .replace(/=\r?\n/g, '') // Remove soft line breaks
        .replace(/=([0-9A-F]{2})/gi, (match, hex) => {
            return String.fromCharCode(parseInt(hex, 16));
        })
        .replace(/=\?([^?]+)\?([QB])\?([^?]+)\?=/gi, (match, charset, encoding, data) => {
            if (encoding.toUpperCase() === 'B') {
                try {
                    const decoded = atob(data.replace(/\s/g, ''));
                    return decoded;
                } catch (e) {
                    return match;
                }
            } else if (encoding.toUpperCase() === 'Q') {
                return decodeQuotedPrintable(data);
            }
            return match;
        });
}

// Parse email to extract subject and body
function parseEmail(emailContent) {
    let subject = '';
    let body = '';
    
    // Try to extract subject from headers (case-insensitive, multiline)
    const subjectMatch = emailContent.match(/^Subject:\s*(.+?)(?:\r?\n|$)/mi);
    if (subjectMatch) {
        subject = decodeQuotedPrintable(subjectMatch[1].trim());
    }
    
    // Strategy: Extract actual email body from MIME structure
    // Handle multipart emails by finding the actual content parts
    
    console.log('Parsing email, subject:', subject);
    console.log('Email length:', emailContent.length);
    
    // NEW APPROACH: Find MIME boundaries and split into parts
    // Find the main multipart boundary
    const boundaryMatch = emailContent.match(/Content-Type:\s*multipart\/[^;]+;\s*boundary=([^\r\n]+)/i);
    const mainBoundary = boundaryMatch ? boundaryMatch[1].trim().replace(/["']/g, '') : null;
    
    if (mainBoundary) {
        console.log('Found multipart boundary:', mainBoundary);
        // Split by boundary
        const boundaryRegex = new RegExp(`--${mainBoundary.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'g');
        const parts = emailContent.split(boundaryRegex);
        console.log('Split into', parts.length, 'parts');
        
        // Process each part
        for (let i = 1; i < parts.length; i++) { // Skip first part (headers)
            const part = parts[i];
            if (!part || part.trim().length < 10) continue;
            
            // Check if this is a content part
            const contentTypeMatch = part.match(/Content-Type:\s*text\/(html|plain)[\s\S]*?/i);
            if (!contentTypeMatch) continue;
            
            const isHTML = contentTypeMatch[0].toLowerCase().includes('text/html');
            const encodingMatch = part.match(/Content-Transfer-Encoding:\s*([^\r\n]+)/i);
            const encoding = encodingMatch ? encodingMatch[1].trim().toLowerCase() : '7bit';
            
            console.log(`Part ${i}: ${isHTML ? 'HTML' : 'plain'}, encoding: ${encoding}`);
            
            // Find content (after double newline)
            const contentStart = part.search(/\r?\n\r?\n/);
            if (contentStart === -1) continue;
            
            let rawContent = part.substring(contentStart).trim();
            // Remove trailing boundary markers
            rawContent = rawContent.replace(/^--[a-zA-Z0-9_\-]+--?/gm, '').trim();
            
            if (rawContent.length < 20) continue;
            
            try {
                let decoded = rawContent;
                
                if (encoding === 'quoted-printable') {
                    decoded = decodeQuotedPrintable(rawContent);
                } else if (encoding === 'base64') {
                    decoded = atob(rawContent.replace(/\s/g, ''));
                }
                
                // Extract text from HTML
                if (isHTML || decoded.includes('<html') || decoded.includes('<body') || decoded.includes('<!doctype')) {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = decoded;
                    const textContent = tempDiv.textContent || tempDiv.innerText || '';
                    const cleaned = textContent.replace(/\s+/g, ' ').trim();
                    if (cleaned.length > 50) {
                        body = cleaned;
                        console.log('SUCCESS: Extracted HTML body, length:', body.length);
                        break;
                    }
                } else if (decoded.length > 50) {
                    body = decoded.trim();
                    console.log('SUCCESS: Extracted plain text body, length:', body.length);
                    break;
                }
            } catch (e) {
                console.error('Decode error:', e);
            }
        }
    }
    
    // FALLBACK: Try regex-based extraction if boundary method failed
    if (!body || body.length < 50) {
        console.log('Boundary method failed, trying regex fallback...');
        // Try to find quoted-printable HTML
        const quotedPrintableRegex = /Content-Type:\s*text\/html[\s\S]*?Content-Transfer-Encoding:\s*quoted-printable[\s\S]*?\r?\n\r?\n([\s\S]+?)(?=\r?\n--[a-zA-Z0-9_\-]+|$)/gi;
        let quotedMatch;
        while ((quotedMatch = quotedPrintableRegex.exec(emailContent)) !== null) {
            try {
                const rawContent = quotedMatch[1];
                const decoded = decodeQuotedPrintable(rawContent);
                
                if (decoded.includes('<html') || decoded.includes('<body') || decoded.includes('<!doctype') || decoded.includes('<div')) {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = decoded;
                    const textContent = tempDiv.textContent || tempDiv.innerText || '';
                    const cleaned = textContent.replace(/\s+/g, ' ').trim();
                    if (cleaned.length > 50) {
                        body = cleaned;
                        console.log('SUCCESS: Found HTML via regex, length:', body.length);
                        break;
                    }
                }
            } catch (e) {
                console.error('Quoted-printable decode error:', e);
            }
        }
    }
    
    // Also try text/plain
    if (!body || body.length < 50) {
        const quotedPlainRegex = /Content-Type:\s*text\/plain[\s\S]*?Content-Transfer-Encoding:\s*quoted-printable[\s\S]*?\r?\n\r?\n([\s\S]+?)(?=\r?\n--[a-zA-Z0-9_\-]+|$)/gi;
        let plainMatch;
        while ((plainMatch = quotedPlainRegex.exec(emailContent)) !== null) {
            try {
                const rawContent = plainMatch[1];
                const decoded = decodeQuotedPrintable(rawContent);
                if (decoded.length > 50) {
                    body = decoded.trim();
                    console.log('SUCCESS: Found plain text via regex, length:', body.length);
                    break;
                }
            } catch (e) {
                console.error('Quoted-printable decode error:', e);
            }
        }
    }
    
    // 2. Try to find and decode base64 text/plain or text/html parts
    const base64Parts = emailContent.match(/Content-Type:\s*text\/(?:plain|html)[\s\S]*?Content-Transfer-Encoding:\s*base64[\s\S]*?\r?\n\r?\n([A-Za-z0-9+\/=\s]+?)(?=\r?\n--[a-zA-Z0-9_\-]+|$)/gi);
    if (base64Parts && base64Parts.length > 0) {
        for (let part of base64Parts) {
            const base64Match = part.match(/Content-Transfer-Encoding:\s*base64[\s\S]*?\r?\n\r?\n([A-Za-z0-9+\/=\s]+?)(?=\r?\n--[a-zA-Z0-9_\-]+|$)/i);
            if (base64Match) {
                try {
                    const base64Data = base64Match[1].replace(/\s/g, '');
                    const decoded = atob(base64Data);
                    
                    // Check if it's HTML
                    if (decoded.includes('<html') || decoded.includes('<body')) {
                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = decoded;
                        const textContent = tempDiv.textContent || tempDiv.innerText || '';
                        if (textContent.length > 50) {
                            body = textContent.trim();
                            break; // Found good content
                        }
                    } else {
                        // Plain text
                        if (decoded.length > 50) {
                            body = decoded.trim();
                            break; // Found good content
                        }
                    }
                } catch (e) {
                    // Base64 decode failed, continue
                }
            }
        }
    }
    
    // 3. If no encoded content found, look for plain text/html in MIME parts
    if (!body || body.length < 50) {
        // Find text/plain or text/html parts (not base64 or quoted-printable)
        const textParts = emailContent.match(/Content-Type:\s*text\/(?:plain|html)[\s\S]*?\r?\n\r?\n([\s\S]+?)(?=\r?\n--[a-zA-Z0-9_\-]+|$)/gi);
        if (textParts && textParts.length > 0) {
            for (let part of textParts) {
                // Skip if it's base64 or quoted-printable encoded (already handled)
                if (part.includes('Content-Transfer-Encoding: base64') || 
                    part.includes('Content-Transfer-Encoding: quoted-printable')) continue;
                
                const contentMatch = part.match(/Content-Type:\s*text\/(?:plain|html)[\s\S]*?\r?\n\r?\n([\s\S]+?)(?=\r?\n--[a-zA-Z0-9_\-]+|$)/i);
                if (contentMatch) {
                    let content = contentMatch[1].trim();
                    
                    // If HTML, extract text
                    if (content.includes('<html') || content.includes('<body') || content.includes('<!doctype')) {
                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = content;
                        content = tempDiv.textContent || tempDiv.innerText || '';
                    }
                    
                    if (content.length > 50) {
                        body = content.trim();
                        break;
                    }
                }
            }
        }
    }
    
    // 3. Fallback: Try to extract any HTML content directly (even if encoding not detected)
    if (!body || body.length < 50) {
        // Look for HTML tags anywhere in the email
        const htmlMatch = emailContent.match(/<html[\s\S]*?<\/html>/i) || 
                         emailContent.match(/<body[\s\S]*?<\/body>/i) ||
                         emailContent.match(/<!doctype[\s\S]*?<\/html>/i);
        if (htmlMatch) {
            try {
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = htmlMatch[0];
                const textContent = tempDiv.textContent || tempDiv.innerText || '';
                const cleaned = textContent.replace(/\s+/g, ' ').trim();
                if (cleaned.length > 50) {
                    body = cleaned;
                    console.log('Found HTML body via direct extraction:', body.substring(0, 100));
                }
            } catch (e) {
                console.error('HTML extraction error:', e);
            }
        }
    }
    
    // 4. Fallback: Find body after headers (for simple emails)
    if (!body || body.length < 50) {
        // Find where headers end (double newline or boundary)
        const headerEnd = emailContent.search(/\r?\n\r?\n/);
        if (headerEnd > 0) {
            let potentialBody = emailContent.substring(headerEnd).trim();
            
            // Remove MIME boundaries
            potentialBody = potentialBody.replace(/^--[a-zA-Z0-9_\-]+[\s\S]*?Content-Type:[\s\S]*?\r?\n\r?\n/gi, '');
            potentialBody = potentialBody.replace(/--[a-zA-Z0-9_\-]+--?/g, '');
            
            // Remove all email headers
            potentialBody = potentialBody.replace(/^[A-Z][a-zA-Z0-9\-]+:\s*.*$/gm, '');
            
            // Remove Content-Type, Content-Transfer-Encoding lines
            potentialBody = potentialBody.replace(/Content-Type:.*$/gmi, '');
            potentialBody = potentialBody.replace(/Content-Transfer-Encoding:.*$/gmi, '');
            potentialBody = potentialBody.replace(/MIME-Version:.*$/gmi, '');
            
            // Clean up
            potentialBody = potentialBody.replace(/\n{3,}/g, '\n\n');
            potentialBody = potentialBody.trim();
            
            if (potentialBody.length > 50 && !potentialBody.match(/^[A-Z][a-zA-Z0-9\-]+:\s*.*$/m)) {
                body = potentialBody;
                console.log('Found body via fallback:', body.substring(0, 100));
            }
        }
    }
    
    // 5. Final cleanup - remove any remaining headers and MIME artifacts
    if (body) {
        // Remove common headers that might have leaked through
        body = body.replace(/^(Delivered-To|Received|X-|ARC-|Return-Path|DKIM|SPF|DMARC|Authentication-Results|Message-ID|Date|From|To|Reply-To|List-Unsubscribe|Errors-To|X-Mailer|X-RPCampaign|X-Message-Reference|MIME-Version|Content-Type|Content-Transfer-Encoding|Content-Disposition|Content-ID|Content-Description):\s*.*$/gmi, '');
        
        // Remove MIME boundaries
        body = body.replace(/--[a-zA-Z0-9_\-]+--?/g, '');
        
        // Remove lines that look like headers
        body = body.replace(/^[A-Z][a-zA-Z0-9\-]+:\s*.*$/gm, '');
        
        // Remove URLs that are too long (tracking pixels, etc.)
        body = body.replace(/https?:\/\/[^\s]{100,}/g, '');
        
        // Clean up whitespace
        body = body.replace(/\s+/g, ' ').trim();
        body = body.replace(/\n{3,}/g, '\n\n');
    }
    
    // 6. If still no good body, try to extract from subject or use a minimal fallback
    if (!body || body.length < 20) {
        // Try to use subject if it's meaningful
        if (subject && subject.length > 10) {
            body = subject;
        } else {
            // Last resort: extract any readable text from the email
            const textMatch = emailContent.match(/[A-Za-z]{10,}/);
            if (textMatch) {
                body = 'Email content detected but parsing failed. Subject: ' + (subject || 'N/A');
            } else {
                body = 'No email content found';
            }
        }
        console.warn('Using fallback body:', body);
    }
    
    console.log('Final parsed body length:', body.length);
    console.log('Final parsed body preview:', body.substring(0, 200));
    
    // Combine subject and body for analysis
    const emailText = subject && body !== subject ? `${subject}\n\n${body}` : body;
    
    // Return both subject and combined body
    return { subject, body: emailText };
}

// Call API to detect phishing
async function detectPhishing(emailText, urls) {
    console.log('=== API REQUEST ===');
    console.log('URL:', `${API_URL}/predict-combined`);
    console.log('Email text length:', emailText.length);
    console.log('URLs:', urls);
    
    // Add timeout to prevent hanging (30 seconds)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
        console.error('API request timeout - aborting after 30 seconds');
        controller.abort();
    }, 30000);
    
    try {
        const response = await fetch(`${API_URL}/predict-combined`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email_text: emailText,
                urls: urls
            }),
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        console.log('Response status:', response.status);
        console.log('Response ok:', response.ok);
        
        if (!response.ok) {
            let errorData;
            try {
                errorData = await response.json();
            } catch (e) {
                errorData = { error: `HTTP ${response.status}: ${response.statusText}` };
            }
            console.error('API Error:', errorData);
            throw new Error(errorData.error || `API request failed with status ${response.status}`);
        }
        
        const result = await response.json();
        console.log('=== RAW API RESPONSE ===');
        console.log('Full response:', result);
        console.log('email_result:', result.email_result);
        console.log('email_result type:', typeof result.email_result);
        console.log('email_result === null?', result.email_result === null);
        console.log('email_result === undefined?', result.email_result === undefined);
        
        if (result.email_result) {
            console.log('email_result.phishing_probability:', result.email_result.phishing_probability);
            console.log('email_result.legitimate_probability:', result.email_result.legitimate_probability);
            console.log('email_result.is_phishing:', result.email_result.is_phishing);
        } else {
            console.error('CRITICAL: email_result is missing!');
        }
        
        return result;
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            console.error('API request timed out after 30 seconds');
            throw new Error('Request timed out. The server may be slow or not responding. Check if the API server is running on http://localhost:5000');
        }
        console.error('Fetch error:', error);
        throw error;
    }
}

// Analyze email for indicators
function analyzeEmailIndicators(emailContent, subject, urls, result) {
    const indicators = [];
    const emailText = (subject + '\n\n' + emailContent).toLowerCase();
    
    // Suspicious keywords
    const suspiciousKeywords = [
        'urgent', 'immediately', 'verify', 'suspended', 'expired', 'limited time',
        'click here', 'act now', 'confirm', 'update', 'security alert', 'unauthorized',
        'verify account', 'verify identity', 'account locked', 'payment required',
        'prize winner', 'congratulations', 'free money', 'claim now', 'click below'
    ];
    const foundKeywords = suspiciousKeywords.filter(keyword => 
        emailText.includes(keyword.toLowerCase())
    );
    if (foundKeywords.length > 0) {
        indicators.push({
            type: 'warning',
            icon: '⚠️',
            title: 'Suspicious Keywords Detected',
            description: `Found ${foundKeywords.length} suspicious keyword(s): ${foundKeywords.slice(0, 3).join(', ')}${foundKeywords.length > 3 ? '...' : ''}`
        });
    }
    
    // URL analysis
    if (urls.length > 0) {
        const suspiciousUrls = urls.filter(url => {
            const urlLower = url.toLowerCase();
            return urlLower.includes('bit.ly') || 
                   urlLower.includes('tinyurl') || 
                   urlLower.includes('t.co') ||
                   urlLower.includes('goo.gl') ||
                   urlLower.match(/http:\/\/(?!www\.)/) || // HTTP (not HTTPS)
                   urlLower.includes('verify') ||
                   urlLower.includes('secure') ||
                   urlLower.includes('update');
        });
        
        if (suspiciousUrls.length > 0) {
            indicators.push({
                type: 'danger',
                icon: '🔗',
                title: 'Suspicious URLs Found',
                description: `${suspiciousUrls.length} of ${urls.length} URL(s) contain suspicious patterns (short links, HTTP, verification links)`
            });
        } else if (urls.length > 3) {
            indicators.push({
                type: 'warning',
                icon: '🔗',
                title: 'Multiple URLs',
                description: `Found ${urls.length} URLs in email (phishing emails often contain many links)`
            });
        }
    }
    
    // Urgency indicators
    const urgencyPatterns = [
        'within 24 hours', 'within 48 hours', 'expires soon', 'limited time',
        'act immediately', 'respond now', 'deadline', 'last chance'
    ];
    const urgencyFound = urgencyPatterns.some(pattern => emailText.includes(pattern));
    if (urgencyFound) {
        indicators.push({
            type: 'warning',
            icon: '⏰',
            title: 'Urgency Language',
            description: 'Email contains urgent language trying to rush you into action'
        });
    }
    
    // Model confidence indicators
    if (result.email_result) {
        const emailProb = result.email_result.phishing_probability;
        // REFINED: Higher thresholds for indicators (less aggressive)
        if (emailProb > 0.85) {
            indicators.push({
                type: 'danger',
                icon: '🤖',
                title: 'High AI Confidence',
                description: `AI model is ${Math.round(emailProb * 100)}% confident this is phishing based on content patterns`
            });
        } else if (emailProb > 0.65) {
            indicators.push({
                type: 'warning',
                icon: '🤖',
                title: 'Moderate AI Confidence',
                description: `AI model shows ${Math.round(emailProb * 100)}% phishing probability - exercise caution`
            });
        } else {
            indicators.push({
                type: 'success',
                icon: '✅',
                title: 'Low Phishing Risk',
                description: `AI model shows ${Math.round((1 - emailProb) * 100)}% confidence this is legitimate`
            });
        }
    }
    
    // URL model results
    if (result.url_results && result.url_results.length > 0) {
        // REFINED: Higher threshold for high-risk URLs (was 0.7, now 0.8)
        const highRiskUrls = result.url_results.filter(r => r.phishing_probability > 0.8);
        if (highRiskUrls.length >= 2) {  // Require at least 2 high-risk URLs
            indicators.push({
                type: 'danger',
                icon: '🌐',
                title: 'High-Risk URLs Detected',
                description: `URL analysis flagged ${highRiskUrls.length} URL(s) as highly suspicious`
            });
        }
    }
    
    // Email structure
    if (emailContent.length < 100) {
        indicators.push({
            type: 'warning',
            icon: '📧',
            title: 'Very Short Email',
            description: 'Email is unusually short - phishing emails are often brief'
        });
    }
    
    // Sender analysis
    const fromMatch = emailContent.match(/^From:\s*(.+?)(?:\r?\n|$)/mi);
    if (fromMatch) {
        const fromEmail = fromMatch[1].toLowerCase();
        // Check for suspicious sender patterns
        if (fromEmail.includes('noreply') || fromEmail.includes('no-reply')) {
            indicators.push({
                type: 'warning',
                icon: '📮',
                title: 'No-Reply Sender',
                description: 'Email is from a no-reply address - legitimate companies usually allow replies'
            });
        }
        if (fromEmail.match(/[0-9]{4,}/)) {
            indicators.push({
                type: 'warning',
                icon: '📮',
                title: 'Suspicious Sender Pattern',
                description: 'Sender email contains unusual numbers - may be auto-generated'
            });
        }
    }
    
    // Grammar and spelling (phishing emails often have errors)
    const commonWords = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
    const words = emailText.split(/\s+/).filter(w => w.length > 2);
    const wordCount = words.length;
    if (wordCount > 0) {
        const typoIndicators = ['teh', 'adn', 'recieve', 'seperate', 'occured'];
        const typosFound = typoIndicators.some(typo => emailText.includes(typo));
        if (typosFound) {
            indicators.push({
                type: 'warning',
                icon: '✍️',
                title: 'Possible Spelling Errors',
                description: 'Email contains common spelling mistakes - phishing emails often have typos'
            });
        }
    }
    
    // Comparison indicators
    if (result.email_result) {
        const emailProb = result.email_result.phishing_probability;
        const legitProb = result.email_result.legitimate_probability;
        const confidenceDiff = Math.abs(emailProb - legitProb);
        
        if (confidenceDiff < 0.2) {
            indicators.push({
                type: 'warning',
                icon: '⚖️',
                title: 'Uncertain Classification',
                description: `Model is uncertain (${Math.round(emailProb * 100)}% phishing vs ${Math.round(legitProb * 100)}% legitimate) - exercise caution`
            });
        } else if (emailProb > 0.80) {
            indicators.push({
                type: 'danger',
                icon: '🔴',
                title: 'Strong Phishing Signals',
                description: `Multiple indicators strongly suggest this is phishing (${Math.round(emailProb * 100)}% confidence)`
            });
        }
    }
    
    // URL count analysis
    if (urls.length === 0) {
        // REFINED: Higher threshold (was 0.5, now 0.65)
        if (result.email_result && result.email_result.phishing_probability > 0.65) {
            indicators.push({
                type: 'info',
                icon: '🔍',
                title: 'Content-Only Phishing',
                description: 'Email flagged as phishing based on content alone (no URLs found)'
            });
        }
    } else if (urls.length === 1) {
        indicators.push({
            type: 'info',
            icon: '🔗',
            title: 'Single URL',
            description: 'Email contains 1 URL - legitimate emails often have single links'
        });
    }
    
    // No indicators found (legitimate) - REFINED: Higher threshold (was 0.3, now 0.4)
    if (indicators.length === 0 && result.email_result && result.email_result.phishing_probability < 0.4) {
        indicators.push({
            type: 'success',
            icon: '✅',
            title: 'No Red Flags',
            description: 'No suspicious patterns detected in email content or URLs'
        });
    }
    
    return indicators;
}

// Display results
function displayResults(result, urls, originalEmailContent, subject, parsedEmailText) {
    // Calculate overall score (0-100) - REFINED: Use weighted average instead of max
    // This provides more nuanced scoring and is less aggressive
    
    const emailProb = result.email_result?.phishing_probability || 0;
    const urlProbs = result.url_results.length > 0 
        ? result.url_results.map(r => r.phishing_probability)
        : [];
    
    // Calculate weighted average (email 60%, URLs 40%)
    let overallScore = 0;
    if (emailProb > 0 && urlProbs.length > 0) {
        // Average of top 2 URLs if multiple, or just max if one
        const topUrls = urlProbs.length >= 2 
            ? urlProbs.sort((a, b) => b - a).slice(0, 2)
            : urlProbs;
        const avgUrlProb = topUrls.reduce((a, b) => a + b, 0) / topUrls.length;
        
        // Weighted average: 60% email, 40% URLs
        overallScore = Math.round((emailProb * 0.6 + avgUrlProb * 0.4) * 100);
    } else if (emailProb > 0) {
        // Only email available
        overallScore = Math.round(emailProb * 100);
    } else if (urlProbs.length > 0) {
        // Only URLs available
        const maxUrlProb = Math.max(...urlProbs);
        overallScore = Math.round(maxUrlProb * 100);
    }
    
    // Ensure score is between 0-100
    overallScore = Math.max(0, Math.min(100, overallScore));
    
    // Update score circle
    const scoreValue = document.getElementById('scoreValue');
    const scoreCircle = document.getElementById('scoreCircle');
    scoreValue.textContent = overallScore;
    
    // Set score circle color - REFINED THRESHOLDS (less aggressive)
    scoreCircle.classList.remove('safe', 'warning', 'danger');
    if (overallScore < 40) {
        // Safe: < 40% (was 30%)
        scoreCircle.classList.add('safe');
    } else if (overallScore < 75) {
        // Warning: 40-75% (was 30-70%)
        scoreCircle.classList.add('warning');
    } else {
        // Danger: >= 75% (was >= 70%)
        scoreCircle.classList.add('danger');
    }
    
    // Update email result
    console.log('=== UPDATING EMAIL RESULT DISPLAY ===');
    console.log('Full result object:', result);
    console.log('result.email_result exists?', !!result.email_result);
    console.log('result.email_result:', result.email_result);
    console.log('result.email_result type:', typeof result.email_result);
    
    const emailPhishingProb = document.getElementById('emailPhishingProb');
    const emailLegitProb = document.getElementById('emailLegitProb');
    
    if (!emailPhishingProb || !emailLegitProb) {
        console.error('ERROR: Could not find email probability elements!');
        console.error('emailPhishingProb:', emailPhishingProb);
        console.error('emailLegitProb:', emailLegitProb);
        return;
    }
    
    if (result.email_result && typeof result.email_result === 'object') {
        const phishingProb = result.email_result.phishing_probability;
        const legitProb = result.email_result.legitimate_probability;
        
        console.log('Raw probabilities from API:');
        console.log('  phishing_probability:', phishingProb, '(type:', typeof phishingProb, ')');
        console.log('  legitimate_probability:', legitProb, '(type:', typeof legitProb, ')');
        
        // Check if there's an error in the result
        if (result.email_result.error) {
            console.error('API returned an error:', result.email_result.error);
            emailPhishingProb.textContent = 'ERROR';
            emailPhishingProb.style.color = 'red';
            emailLegitProb.textContent = 'ERROR';
            emailLegitProb.style.color = 'red';
            return;
        }
        
        // Convert to numbers if they're strings
        const phishingNum = typeof phishingProb === 'number' ? phishingProb : parseFloat(phishingProb) || 0;
        const legitNum = typeof legitProb === 'number' ? legitProb : parseFloat(legitProb) || 0;
        
        console.log('Converted probabilities:');
        console.log('  phishing:', phishingNum);
        console.log('  legitimate:', legitNum);
        
        const phishingPercent = Math.round(phishingNum * 100);
        const legitPercent = Math.round(legitNum * 100);
        
        console.log('Setting display:');
        console.log('  phishing:', phishingPercent + '%');
        console.log('  legitimate:', legitPercent + '%');
        
        // Reset colors
        emailPhishingProb.style.color = '';
        emailLegitProb.style.color = '';
        
        emailPhishingProb.textContent = `${phishingPercent}%`;
        emailLegitProb.textContent = `${legitPercent}%`;
        
        // Verify they were set
        console.log('After setting, values are:');
        console.log('  emailPhishingProb.textContent:', emailPhishingProb.textContent);
        console.log('  emailLegitProb.textContent:', emailLegitProb.textContent);
        
        // Validate probabilities sum to ~100%
        const probSum = phishingPercent + legitPercent;
        if (probSum === 0) {
            console.error('CRITICAL ERROR: Both probabilities are 0%! This should never happen.');
            console.error('This means the API returned 0 for both, which indicates a serious problem.');
            console.error('Model 1 may not be working correctly. Check API server logs.');
            // Show error visually
            emailPhishingProb.textContent = 'ERROR';
            emailPhishingProb.style.color = 'red';
            emailLegitProb.textContent = 'ERROR';
            emailLegitProb.style.color = 'red';
        } else if (Math.abs(probSum - 100) > 1) {
            console.warn(`WARNING: Probabilities don't sum to 100%! Sum: ${probSum}%`);
            console.warn('This might indicate an issue with the API response.');
            // Normalize if possible
            if (probSum > 0) {
                const normalizedPhishing = Math.round((phishingPercent / probSum) * 100);
                const normalizedLegit = Math.round((legitPercent / probSum) * 100);
                emailPhishingProb.textContent = `${normalizedPhishing}%`;
                emailLegitProb.textContent = `${normalizedLegit}%`;
                console.log(`Normalized probabilities: phishing=${normalizedPhishing}%, legitimate=${normalizedLegit}%`);
            }
        } else if (phishingPercent === 0 && legitPercent === 100) {
            console.warn('Model returned 0% phishing, 100% legitimate - this might be correct for a legitimate email');
            console.warn('If this seems wrong, verify Model 1 is working properly');
        }
    } else {
        console.error('ERROR: result.email_result is null/undefined or not an object!');
        console.error('This means Model 1 did not return results. Check API server logs.');
        emailPhishingProb.textContent = 'N/A';
        emailPhishingProb.style.color = 'red';
        emailLegitProb.textContent = 'N/A';
        emailLegitProb.style.color = 'red';
    }
    
    // ALWAYS display parsed email content (regardless of email_result)
    const parsedEmailTextEl = document.getElementById('parsedEmailText');
    if (parsedEmailTextEl) {
        // Show the raw content that was sent to the model (no parsing)
        // Priority: parsedEmailText parameter > window.lastParsedEmail > originalEmailContent
        let textToShow = parsedEmailText || window.lastParsedEmail || originalEmailContent;
        
        console.log('=== DISPLAYING CONTENT DEBUG ===');
        console.log('parsedEmailText param:', parsedEmailText ? parsedEmailText.substring(0, 100) : 'NULL');
        console.log('window.lastParsedEmail:', window.lastParsedEmail ? window.lastParsedEmail.substring(0, 100) : 'NULL');
        console.log('originalEmailContent:', originalEmailContent ? originalEmailContent.substring(0, 100) : 'NULL');
        console.log('textToShow before check:', textToShow ? textToShow.substring(0, 100) : 'NULL');
        
        // If still empty, use original content
        if (!textToShow || textToShow.length < 10) {
            textToShow = originalEmailContent || 'No content available';
            console.log('Using originalEmailContent as fallback');
        }
        
        // Limit display to first 5000 characters for performance (full content was sent to model)
        const displayText = textToShow.length > 5000 
            ? textToShow.substring(0, 5000) + '\n\n... (content truncated for display, full content was analyzed)'
            : textToShow;
        
        console.log('=== DISPLAYING CONTENT SENT TO MODEL ===');
        console.log('Full content length:', textToShow.length);
        console.log('Display length:', displayText.length);
        console.log('Preview:', displayText.substring(0, 300));
        console.log('Setting innerHTML...');
        
        // Highlight suspicious keywords in the content
        const highlightedText = highlightSuspiciousContent(displayText);
        parsedEmailTextEl.innerHTML = highlightedText || displayText || 'No content available';
        
        // Force update - make sure content is there
        if (!parsedEmailTextEl.textContent || parsedEmailTextEl.textContent.trim().length < 10) {
            console.warn('Content not set properly, forcing textContent');
            parsedEmailTextEl.textContent = displayText || 'No content available';
        }
        
        // Make sure the element is visible
        parsedEmailTextEl.style.display = 'block';
        console.log('Content set! Element text length:', parsedEmailTextEl.textContent.length);
    } else {
        console.error('parsedEmailText element not found!');
    }
    
    // Update URL results
    const urlList = document.getElementById('urlList');
    if (result.url_results && result.url_results.length > 0) {
        urlList.innerHTML = result.url_results.map(urlResult => {
            const score = Math.round(urlResult.phishing_probability * 100);
            let scoreClass = 'safe';
            // REFINED THRESHOLDS: Higher thresholds for URL scores
            if (score >= 80) scoreClass = 'danger';  // Was 70
            else if (score >= 50) scoreClass = 'warning';  // Was 30
            
            return `
                <div class="url-item">
                    <span class="url-text" title="${urlResult.url}">${urlResult.url}</span>
                    <span class="url-score ${scoreClass}">${score}%</span>
                </div>
            `;
        }).join('');
    } else {
        urlList.innerHTML = '<div style="color: #9ca3af; font-size: 12px; padding: 8px;">No URLs found in email</div>';
    }
    
    // Show/hide warning box
    // Only show warning if threat score is above 50%
    const warningBox = document.getElementById('warningBox');
    if (overallScore > 50) {
        warningBox.style.display = 'flex';
    } else {
        warningBox.style.display = 'none';
    }
    
    // Analyze and display indicators
    const indicators = analyzeEmailIndicators(originalEmailContent, subject, urls, result);
    displayIndicators(indicators);
    
    // Show results - CRITICAL: Make sure this always runs
    console.log('=== SHOWING RESULTS SECTION ===');
    console.log('resultsSection element:', resultsSection);
    console.log('resultsSection.classList before:', resultsSection ? Array.from(resultsSection.classList) : 'N/A');
    
    if (resultsSection) {
        // Remove hidden class FIRST
        resultsSection.classList.remove('hidden');
        
        // Force display with inline style using setProperty with 'important' flag
        // This overrides the CSS !important rule in .hidden class
        resultsSection.style.setProperty('display', 'block', 'important');
        resultsSection.style.setProperty('visibility', 'visible', 'important');
        resultsSection.style.setProperty('opacity', '1', 'important');
        
        console.log('resultsSection.classList after:', Array.from(resultsSection.classList));
        console.log('resultsSection.style.display:', resultsSection.style.display);
        console.log('resultsSection.style.visibility:', resultsSection.style.visibility);
        console.log('Results section should now be visible!');
        
        // Double-check it's visible after a brief delay
        setTimeout(() => {
            const computedStyle = window.getComputedStyle(resultsSection);
            console.log('Computed display:', computedStyle.display);
            console.log('Computed visibility:', computedStyle.visibility);
            console.log('Computed opacity:', computedStyle.opacity);
            if (computedStyle.display === 'none' || computedStyle.visibility === 'hidden') {
                console.error('WARNING: Results section is still hidden! Trying alternative method...');
                // Last resort: create a new style element to override
                const style = document.createElement('style');
                style.textContent = '#resultsSection { display: block !important; visibility: visible !important; opacity: 1 !important; }';
                document.head.appendChild(style);
                console.log('Injected style tag to force display');
            } else {
                console.log('SUCCESS: Results section is visible!');
            }
        }, 100);
    } else {
        console.error('CRITICAL ERROR: resultsSection element is null!');
        console.error('This means the HTML element with id="resultsSection" was not found!');
        console.error('Available elements:', Array.from(document.querySelectorAll('[id]')).map(el => el.id));
    }
}

// Highlight suspicious content in parsed email
function highlightSuspiciousContent(text) {
    const suspiciousKeywords = [
        'urgent', 'immediately', 'verify', 'suspended', 'expired', 'limited time',
        'click here', 'act now', 'confirm', 'update', 'security alert', 'unauthorized',
        'verify account', 'verify identity', 'account locked', 'payment required',
        'prize winner', 'congratulations', 'free money', 'claim now', 'click below',
        'within 24 hours', 'within 48 hours', 'expires soon', 'deadline', 'last chance'
    ];
    
    let highlighted = text;
    suspiciousKeywords.forEach(keyword => {
        const regex = new RegExp(`(${keyword})`, 'gi');
        highlighted = highlighted.replace(regex, '<mark class="suspicious-highlight">$1</mark>');
    });
    
    // Also highlight URLs
    const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`\[\]]+)/gi;
    highlighted = highlighted.replace(urlRegex, '<mark class="url-highlight">$1</mark>');
    
    return highlighted;
}

// Display indicators in details section
function displayIndicators(indicators) {
    const detailsList = document.getElementById('detailsList');
    
    if (indicators.length === 0) {
        detailsList.innerHTML = '<div class="indicator-item success"><div class="indicator-content"><strong>No suspicious indicators found</strong></div></div>';
        return;
    }
    
    detailsList.innerHTML = indicators.map(indicator => {
        const typeClass = indicator.type || 'info';
        return `
            <div class="indicator-item ${typeClass}">
                <div class="indicator-icon">${indicator.icon}</div>
                <div class="indicator-content">
                    <div class="indicator-title">${indicator.title}</div>
                    <div class="indicator-description">${indicator.description}</div>
                </div>
            </div>
        `;
    }).join('');
}

// Show error
function showError(message) {
    document.getElementById('errorMessage').textContent = message;
    errorState.classList.remove('hidden');
    loadingState.classList.add('hidden');
    resultsSection.classList.add('hidden');
}

// Periodic API status check
setInterval(checkAPIStatus, 30000); // Check every 30 seconds

