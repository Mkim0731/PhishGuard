# PhishGuard Chrome Extension

A professional Chrome extension for detecting phishing emails using dual AI models.

## Features

- **Clean, Professional UI** - Modern gradient design with intuitive interface
- **Full Email Analysis** - Analyzes complete email content including headers
- **Dual Model Detection** - Uses both email content and URL analysis
- **Score Display** - Shows phishing probability score (0-100)
- **Real-time Detection** - Fast analysis via local API server
- **Gmail & Outlook Support** - Automatically extracts emails from Gmail and Outlook

## Installation

1. **Train the models first** (if not already done):
   ```bash
   cd ../..
   python train_both_models.py
   ```

2. **Start the API server**:
   ```bash
   cd api_server
   python app.py
   ```

3. **Load the extension in Chrome**:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (top right)
   - Click "Load unpacked"
   - Select the `chrome_extension` folder

## Usage

### Method 1: Paste Email Content
1. Open the extension popup
2. Paste the full email content (including headers) into the text area
3. Click "Detect Phishing"
4. View the results:
   - Overall phishing score (0-100)
   - Email content analysis
   - URL analysis (if URLs found)
   - Warning box (if phishing detected)

### Method 2: Load from Gmail/Outlook
1. Open an email in Gmail or Outlook
2. Open the extension popup
3. Click "Load from Page"
4. The email content will be automatically extracted
5. Click "Detect Phishing"

## Score Interpretation

- **0-30**: Safe (Green) - Email appears legitimate
- **30-70**: Warning (Yellow) - Exercise caution
- **70-100**: Danger (Red) - High phishing probability

## API Connection

The extension connects to a local API server running on `http://localhost:5000`.

**Status Indicator:**
- 🟢 Green dot = Connected
- 🔴 Red dot = Disconnected

Make sure the API server is running before using the extension.

## File Structure

```
chrome_extension/
├── manifest.json       # Extension configuration
├── popup.html          # Main UI
├── popup.css           # Styling
├── popup.js            # Main logic
├── content.js          # Email extraction from Gmail/Outlook
├── background.js       # Service worker
├── content.css         # Content script styles
└── icons/              # Extension icons
```

## Permissions

The extension requires:
- `activeTab` - To access current tab content
- `storage` - To save email content temporarily
- Gmail/Outlook host permissions - To extract emails

## Troubleshooting

**Extension shows "Disconnected":**
- Make sure API server is running (`python api_server/app.py`)
- Check that server is on `http://localhost:5000`

**"Load from Page" doesn't work:**
- Make sure you're on Gmail or Outlook
- Refresh the page and try again

**No results shown:**
- Check browser console for errors (F12)
- Verify API server is responding (`http://localhost:5000/health`)

## Development

To modify the extension:
1. Make changes to files
2. Go to `chrome://extensions/`
3. Click the refresh icon on the extension card
4. Test your changes

## Notes

- Icons are optional (extension works without them)
- Email content is stored locally (not sent anywhere except your API server)
- All processing happens locally on your machine






