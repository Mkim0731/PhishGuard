// PhishGuard Content Script - Extracts email content from Gmail/Outlook

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'extractEmail') {
        const emailContent = extractEmailContent();
        sendResponse({ emailContent });
    }
    return true; // Keep channel open for async response
});

// Extract email content from page
function extractEmailContent() {
    const url = window.location.href;
    
    if (url.includes('mail.google.com')) {
        return extractGmailEmail();
    } else if (url.includes('outlook.live.com') || url.includes('outlook.office.com')) {
        return extractOutlookEmail();
    } else {
        return extractGenericEmail();
    }
}

// Extract from Gmail - Copy entire page
function extractGmailEmail() {
    let emailContent = '';
    
    try {
        // First, try to get the full email source if "Show original" is available
        // Otherwise, get the entire page content
        
        // Try to find "Show original" link and get full email
        const showOriginalLink = Array.from(document.querySelectorAll('a')).find(a => 
            a.textContent.toLowerCase().includes('show original') || 
            a.textContent.toLowerCase().includes('view source')
        );
        
        if (showOriginalLink) {
            // If we can access the original, use that
            // For now, we'll get the full page HTML
            emailContent = document.documentElement.outerHTML;
        } else {
            // Get subject
            const subjectElement = document.querySelector('h2[data-thread-perm-id]') || 
                                  document.querySelector('h2.hP') ||
                                  document.querySelector('[data-thread-perm-id] h2');
            const subject = subjectElement ? subjectElement.textContent.trim() : '';
            
            // Get sender
            const senderElement = document.querySelector('span[email]') ||
                                 document.querySelector('.gD');
            const sender = senderElement ? senderElement.textContent.trim() : '';
            
            // Get the entire email view HTML (not just text)
            const emailView = document.querySelector('[role="main"]') || 
                            document.querySelector('.nH') ||
                            document.body;
            
            // Get full HTML of the email view
            emailContent = emailView ? emailView.innerHTML : document.body.innerHTML;
            
            // Add headers
            const headers = [];
            if (subject) headers.push(`Subject: ${subject}`);
            if (sender) headers.push(`From: ${sender}`);
            headers.push(`URL: ${window.location.href}`);
            
            emailContent = headers.join('\n') + '\n\n' + emailContent;
        }
        
    } catch (error) {
        console.error('Gmail extraction error:', error);
        // Fallback: get entire page
        emailContent = document.documentElement.outerHTML;
    }
    
    return emailContent.trim();
}

// Extract from Outlook - Copy entire page
function extractOutlookEmail() {
    let emailContent = '';
    
    try {
        // Get subject
        const subjectElement = document.querySelector('[aria-label*="Subject"]') ||
                              document.querySelector('div[role="heading"]') ||
                              document.querySelector('h1');
        const subject = subjectElement ? subjectElement.textContent.trim() : '';
        
        // Get sender
        const senderElement = document.querySelector('[aria-label*="From"]') ||
                             document.querySelector('[email]');
        const sender = senderElement ? senderElement.textContent.trim() : '';
        
        // Get the entire email view HTML
        const emailView = document.querySelector('[role="main"]') ||
                         document.querySelector('.ms-MessageBody') ||
                         document.querySelector('div[aria-label*="Message body"]') ||
                         document.body;
        
        // Get full HTML
        emailContent = emailView ? emailView.innerHTML : document.body.innerHTML;
        
        // Build email content with headers
        const headers = [];
        if (subject) headers.push(`Subject: ${subject}`);
        if (sender) headers.push(`From: ${sender}`);
        headers.push(`URL: ${window.location.href}`);
        
        emailContent = headers.join('\n') + '\n\n' + emailContent;
        
    } catch (error) {
        console.error('Outlook extraction error:', error);
        // Fallback: get entire page
        emailContent = document.documentElement.outerHTML;
    }
    
    return emailContent.trim();
}

// Generic email extraction (fallback) - Copy entire page
function extractGenericEmail() {
    // Copy the entire page content
    // Try to get the full HTML source first
    let emailContent = '';
    
    // Method 1: Try to get full page HTML (if available)
    if (document.documentElement) {
        emailContent = document.documentElement.outerHTML;
    } else {
        // Method 2: Get body HTML
        emailContent = document.body.innerHTML;
    }
    
    // If HTML is too large or not useful, get text content
    if (!emailContent || emailContent.length < 100) {
        emailContent = document.body.innerText || document.body.textContent || '';
    }
    
    // Add page URL as header
    const url = window.location.href;
    const headers = `From: Page Content\nURL: ${url}\nDate: ${new Date().toISOString()}\n\n`;
    
    return headers + emailContent;
}

// Also listen for when user wants to analyze current email
// This can be triggered from the extension popup






