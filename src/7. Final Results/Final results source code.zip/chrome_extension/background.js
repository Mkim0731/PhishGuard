// PhishGuard Background Service Worker

// Listen for extension installation
chrome.runtime.onInstalled.addListener(() => {
    console.log('PhishGuard extension installed');
    
    // Set default API URL
    chrome.storage.local.set({ apiUrl: 'http://localhost:5000' });
});

// Handle messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'checkAPI') {
        checkAPIHealth().then(healthy => {
            sendResponse({ healthy });
        });
        return true; // Keep channel open
    }
});

// Check API health
async function checkAPIHealth() {
    try {
        const result = await chrome.storage.local.get(['apiUrl']);
        const apiUrl = result.apiUrl || 'http://localhost:5000';
        
        const response = await fetch(`${apiUrl}/health`);
        const data = await response.json();
        return data.status === 'healthy';
    } catch (error) {
        return false;
    }
}






